# Build the Block Blast APK using only an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`. GitHub's cloud runner builds the APK; you do not need Android Studio or a computer.

## One-time setup
1. In your Android browser, sign in to GitHub or create an account at https://github.com.
2. Create a **new repository**. A private repository is fine. Name it `block-blast-android`.
3. Extract this ZIP using your phone's Files app or a ZIP utility.
4. Open the new repository on github.com in your browser. If necessary, use the browser menu and select **Desktop site**.
5. Use **Add file → Upload files** and upload the extracted project files and folders, including the hidden `.github/workflows/build-apk.yml` file. If your phone's file picker cannot select folders or hidden files, use a GitHub-compatible mobile git client, or use an online git workspace that can upload/extract the ZIP and push the complete folder structure.
6. Commit the uploaded files to the `main` branch.

## Start the cloud build
1. In the repository, open the **Actions** tab.
2. Choose **Build Android APK**. If prompted, enable Actions for the repository.
3. Tap **Run workflow** and select the `main` branch. A push to `main` should also trigger a build automatically.
4. Wait for the workflow to finish with a green check mark.
5. Open the completed workflow run, scroll to **Artifacts**, and download `block-blast-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Tap `app-debug.apk` to install. Android may ask you to allow installation from that browser or file manager; only enable this for the app you trust, and turn it off again afterward if desired.

## Notes
- This produces a **debug APK for testing**, not a signed release APK for Play Store publication.
- The APK build can fail if the source project has compilation errors; check the log in the failed GitHub Actions run.
- Do not commit `.env.local`, passwords, or API keys to a public repository.
- The generated Android project is created during the cloud build, so an `android/` folder does not need to be uploaded.
