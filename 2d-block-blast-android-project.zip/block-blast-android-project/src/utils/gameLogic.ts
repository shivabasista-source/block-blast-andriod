import { Grid, Piece, SHAPE_DEFINITIONS, ThemeConfig, HintPlacement } from '../types/game';

export const GRID_SIZE = 10;

/**
 * Creates an empty 10x10 grid
 */
export function createEmptyGrid(): Grid {
  return Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
}

/**
 * Generates 3 pieces for the bottom tray
 */
export function generatePieces(theme: ThemeConfig): Piece[] {
  const pieces: Piece[] = [];
  const colors = theme.blockColors;

  for (let i = 0; i < 3; i++) {
    // Weighted random selection
    const totalWeight = SHAPE_DEFINITIONS.reduce((acc, curr) => acc + curr.weight, 0);
    let rand = Math.random() * totalWeight;
    let chosenShape = SHAPE_DEFINITIONS[0];

    for (const shape of SHAPE_DEFINITIONS) {
      if (rand < shape.weight) {
        chosenShape = shape;
        break;
      }
      rand -= shape.weight;
    }

    const color = colors[Math.floor(Math.random() * colors.length)];
    const height = chosenShape.matrix.length;
    const width = chosenShape.matrix[0].length;

    pieces.push({
      id: `piece-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`,
      shapeId: chosenShape.id,
      matrix: chosenShape.matrix,
      color,
      width,
      height,
    });
  }

  return pieces;
}

/**
 * Validates if a piece can be placed at (row, col)
 */
export function canPlacePiece(grid: Grid, piece: Piece, row: number, col: number): boolean {
  for (let r = 0; r < piece.height; r++) {
    for (let c = 0; c < piece.width; c++) {
      if (piece.matrix[r][c] === 1) {
        const targetRow = row + r;
        const targetCol = col + c;

        // Check grid bounds
        if (targetRow < 0 || targetRow >= GRID_SIZE || targetCol < 0 || targetCol >= GRID_SIZE) {
          return false;
        }

        // Check if cell is already occupied
        if (grid[targetRow][targetCol] !== null) {
          return false;
        }
      }
    }
  }
  return true;
}

/**
 * Places piece on the grid and returns a new grid clone
 */
export function placePiece(grid: Grid, piece: Piece, row: number, col: number): Grid {
  const newGrid = grid.map(r => [...r]);

  for (let r = 0; r < piece.height; r++) {
    for (let c = 0; c < piece.width; c++) {
      if (piece.matrix[r][c] === 1) {
        newGrid[row + r][col + c] = piece.color;
      }
    }
  }

  return newGrid;
}

export interface LineClearResult {
  newGrid: Grid;
  clearedRows: number[];
  clearedCols: number[];
  clearedCells: { row: number; col: number; color: string }[];
  linesCount: number;
  scoreGained: number;
}

/**
 * Detects completed horizontal and vertical lines, clears them,
 * and calculates scoring according to specifications:
 * - Placement: 10 points per single block piece (3 pieces = 30 pts, 9 pieces = 90 pts, etc.)
 * - 1 line: 200 pts
 * - 2 lines: 400 pts
 * - 3 lines: 600 pts
 * - 4 lines: 800 pts
 * - N lines: N * 200 pts (+ combo bonuses)
 */
export function checkAndClearLines(
  grid: Grid,
  placementScore: number,
  currentCombo: number
): LineClearResult {
  const clearedRows: number[] = [];
  const clearedCols: number[] = [];

  // Check rows
  for (let r = 0; r < GRID_SIZE; r++) {
    if (grid[r].every(cell => cell !== null)) {
      clearedRows.push(r);
    }
  }

  // Check columns
  for (let c = 0; c < GRID_SIZE; c++) {
    let colFilled = true;
    for (let r = 0; r < GRID_SIZE; r++) {
      if (grid[r][c] === null) {
        colFilled = false;
        break;
      }
    }
    if (colFilled) {
      clearedCols.push(c);
    }
  }

  const linesCount = clearedRows.length + clearedCols.length;
  const clearedCells: { row: number; col: number; color: string }[] = [];
  const newGrid = grid.map(r => [...r]);

  if (linesCount > 0) {
    const visited = new Set<string>();

    // Collect cells from cleared rows
    clearedRows.forEach(r => {
      for (let c = 0; c < GRID_SIZE; c++) {
        const key = `${r},${c}`;
        if (!visited.has(key) && grid[r][c] !== null) {
          visited.add(key);
          clearedCells.push({ row: r, col: c, color: grid[r][c]! });
        }
        newGrid[r][c] = null;
      }
    });

    // Collect cells from cleared cols
    clearedCols.forEach(c => {
      for (let r = 0; r < GRID_SIZE; r++) {
        const key = `${r},${c}`;
        if (!visited.has(key) && grid[r][c] !== null) {
          visited.add(key);
          clearedCells.push({ row: r, col: c, color: grid[r][c]! });
        }
        newGrid[r][c] = null;
      }
    });
  }

  // Score Calculation: 10 points for each placed block cell + line clears + combos
  let scoreGained = placementScore;
  if (linesCount > 0) {
    // 200 points per line: 1 line = 200, 2 lines = 400, 3 lines = 600, 4 lines = 800, etc.
    const baseLinePoints = linesCount * 200;
    const comboBonus = currentCombo > 1 ? (currentCombo - 1) * 50 : 0;
    scoreGained += baseLinePoints + comboBonus;
  }

  return {
    newGrid,
    clearedRows,
    clearedCols,
    clearedCells,
    linesCount,
    scoreGained,
  };
}

/**
 * Checks whether at least one remaining piece in the tray can fit anywhere on the grid
 */
export function hasAnyValidMove(grid: Grid, pieces: (Piece | null)[]): boolean {
  const activePieces = pieces.filter((p): p is Piece => p !== null);
  if (activePieces.length === 0) return true; // Will trigger new piece generation

  for (const piece of activePieces) {
    const maxRow = GRID_SIZE - piece.height;
    const maxCol = GRID_SIZE - piece.width;

    for (let r = 0; r <= maxRow; r++) {
      for (let c = 0; c <= maxCol; c++) {
        if (canPlacePiece(grid, piece, r, c)) {
          return true; // Found a valid placement
        }
      }
    }
  }

  return false;
}

/**
 * Finds the best valid hint placement for the player
 */
export function findBestHint(grid: Grid, pieces: (Piece | null)[]): HintPlacement | null {
  const activePieces = pieces
    .map((p, idx) => ({ piece: p, index: idx }))
    .filter((item): item is { piece: Piece; index: number } => item.piece !== null);

  if (activePieces.length === 0) return null;

  let bestMove: HintPlacement | null = null;
  let bestScore = -1;

  for (const { piece, index } of activePieces) {
    const maxRow = GRID_SIZE - piece.height;
    const maxCol = GRID_SIZE - piece.width;

    for (let r = 0; r <= maxRow; r++) {
      for (let c = 0; c <= maxCol; c++) {
        if (canPlacePiece(grid, piece, r, c)) {
          // Score this move: check if it completes a line!
          const tempGrid = placePiece(grid, piece, r, c);
          let completedLines = 0;

          // Rows
          for (let row = 0; row < GRID_SIZE; row++) {
            if (tempGrid[row].every(cell => cell !== null)) completedLines++;
          }
          // Cols
          for (let col = 0; col < GRID_SIZE; col++) {
            let colFull = true;
            for (let row = 0; row < GRID_SIZE; row++) {
              if (tempGrid[row][col] === null) {
                colFull = false;
                break;
              }
            }
            if (colFull) completedLines++;
          }

          const moveScore = completedLines * 100 + (r + c); // tie breaker
          if (moveScore > bestScore) {
            bestScore = moveScore;
            const cells: [number, number][] = [];
            for (let pr = 0; pr < piece.height; pr++) {
              for (let pc = 0; pc < piece.width; pc++) {
                if (piece.matrix[pr][pc] === 1) {
                  cells.push([r + pr, c + pc]);
                }
              }
            }
            bestMove = {
              pieceIndex: index,
              row: r,
              col: c,
              cells,
            };
          }
        }
      }
    }
  }

  return bestMove;
}

/**
 * Revival helper: clears a central 4x4 zone or up to 20 blocks with massive blast
 */
export function reviveGrid(grid: Grid): { newGrid: Grid; clearedCells: { row: number; col: number; color: string }[] } {
  const newGrid = grid.map(r => [...r]);
  const clearedCells: { row: number; col: number; color: string }[] = [];

  // Clear 4x4 center area (rows 3..6, cols 3..6)
  for (let r = 2; r <= 7; r++) {
    for (let c = 2; c <= 7; c++) {
      if (newGrid[r][c] !== null) {
        clearedCells.push({ row: r, col: c, color: newGrid[r][c]! });
        newGrid[r][c] = null;
      }
    }
  }

  // If center had few blocks, clear random filled blocks to free at least 15 spaces
  if (clearedCells.length < 15) {
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        if (newGrid[r][c] !== null && clearedCells.length < 20) {
          clearedCells.push({ row: r, col: c, color: newGrid[r][c]! });
          newGrid[r][c] = null;
        }
      }
    }
  }

  return { newGrid, clearedCells };
}
