import React, { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { MainMenu } from './components/MainMenu';
import { Grid2D, ScoreBurst } from './components/Grid2D';
import { TrayPieces } from './components/TrayPieces';
import { ScoreBoard } from './components/ScoreBoard';
import { GameOverModal } from './components/GameOverModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { soundManager } from './audio/soundManager';
import {
  Grid,
  Piece,
  ThemeConfig,
  getThemeForScore,
} from './types/game';
import {
  createEmptyGrid,
  generatePieces,
  canPlacePiece,
  placePiece,
  checkAndClearLines,
  hasAnyValidMove,
  findBestHint,
  reviveGrid,
  GRID_SIZE,
} from './utils/gameLogic';

export default function App() {
  // Navigation State: Main Menu vs Game
  const [isInGame, setIsInGame] = useState<boolean>(false);

  // Game State
  const [grid, setGrid] = useState<Grid>(() => createEmptyGrid());
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('blockblast_highscore') || '0', 10);
    } catch {
      return 0;
    }
  });
  const [combo, setCombo] = useState<number>(0);
  const [maxCombo, setMaxCombo] = useState<number>(0);
  const [linesCleared, setLinesCleared] = useState<number>(0);
  const [theme, setTheme] = useState<ThemeConfig>(() => getThemeForScore(0));
  const [pieces, setPieces] = useState<(Piece | null)[]>(() => generatePieces(getThemeForScore(0)));

  // Powerups & Modals
  const [hintsRemaining, setHintsRemaining] = useState<number>(3);
  const [hintCells, setHintCells] = useState<[number, number][] | null>(null);
  const [canRevive, setCanRevive] = useState<boolean>(true);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);

  // Sound & Music settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => soundManager.soundEnabled);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(() => soundManager.musicEnabled);

  // Shatter animation state (passed to 2D canvas)
  const [shatteringCells, setShatteringCells] = useState<{ row: number; col: number; color: string }[] | null>(null);

  // Smooth block placement animation state
  const [placedAnimationCells, setPlacedAnimationCells] = useState<Set<string> | null>(null);

  // Big Gained Score Burst State
  const [scoreBurst, setScoreBurst] = useState<ScoreBurst | null>(null);

  // Interactive Dragging State
  const [draggedPieceIndex, setDraggedPieceIndex] = useState<number | null>(null);
  const [selectedPieceIndex, setSelectedPieceIndex] = useState<number | null>(null);
  const [dragPointer, setDragPointer] = useState<{ x: number; y: number } | null>(null);
  const [hoveredPlacement, setHoveredPlacement] = useState<{
    piece: Piece;
    row: number;
    col: number;
    isValid: boolean;
  } | null>(null);

  // References
  const boardRef = useRef<HTMLDivElement>(null);
  const gridStateRef = useRef<Grid>(grid);
  gridStateRef.current = grid;
  const piecesStateRef = useRef<(Piece | null)[]>(pieces);
  piecesStateRef.current = pieces;

  // Persist High Score
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      try {
        localStorage.setItem('blockblast_highscore', String(score));
      } catch {}
    }
  }, [score, highScore]);

  // Handle Drag Start (smooth pickup)
  const handleDragStart = useCallback((index: number, clientX: number, clientY: number) => {
    if (isGameOver) return;
    const piece = piecesStateRef.current[index];
    if (!piece) return;

    soundManager.playPickup();
    setDraggedPieceIndex(index);
    setSelectedPieceIndex(index);
    setDragPointer({ x: clientX, y: clientY });
    setHintCells(null); // Clear active hint
  }, [isGameOver]);

  // Helper to calculate target grid cell from screen position in 2D
  const calculateGridCoords = useCallback((screenX: number, screenY: number, piece: Piece) => {
    if (!boardRef.current) return null;
    const rect = boardRef.current.getBoundingClientRect();

    // Move touch position upward so player's finger does not block the piece or preview
    const isTouch = window.matchMedia('(pointer: coarse)').matches;
    const verticalOffset = isTouch ? 70 : 35;
    const effectiveY = screenY - verticalOffset;

    // Buffer margin around board
    const margin = 28;
    if (
      screenX < rect.left - margin ||
      screenX > rect.right + margin ||
      effectiveY < rect.top - margin ||
      effectiveY > rect.bottom + margin
    ) {
      return null;
    }

    const cellW = rect.width / GRID_SIZE;
    const cellH = rect.height / GRID_SIZE;

    const relX = screenX - rect.left;
    const relY = effectiveY - rect.top;

    const hoveredCol = Math.floor(relX / cellW);
    const hoveredRow = Math.floor(relY / cellH);

    // Center piece on cursor/finger
    const targetCol = hoveredCol - Math.floor((piece.width - 1) / 2);
    const targetRow = hoveredRow - Math.floor((piece.height - 1) / 2);

    return { targetRow, targetCol };
  }, []);

  // Handle Global Pointer Move during drag
  useEffect(() => {
    if (draggedPieceIndex === null) return;
    const piece = piecesStateRef.current[draggedPieceIndex];
    if (!piece) return;

    const handlePointerMove = (e: PointerEvent) => {
      setDragPointer({ x: e.clientX, y: e.clientY });

      const coords = calculateGridCoords(e.clientX, e.clientY, piece);
      if (!coords) {
        setHoveredPlacement(null);
        return;
      }

      const { targetRow, targetCol } = coords;
      const isValid = canPlacePiece(gridStateRef.current, piece, targetRow, targetCol);

      // Trigger louder, tactile moving sound whenever block snaps to a new position on the 10x10 grid
      setHoveredPlacement(prev => {
        if (!prev || prev.row !== targetRow || prev.col !== targetCol) {
          soundManager.playHoverSnap(isValid);
        }
        return {
          piece,
          row: targetRow,
          col: targetCol,
          isValid,
        };
      });
    };

    const handlePointerUp = (e: PointerEvent) => {
      const coords = calculateGridCoords(e.clientX, e.clientY, piece);
      if (coords && canPlacePiece(gridStateRef.current, piece, coords.targetRow, coords.targetCol)) {
        // Valid Placement!
        placeAndEvaluate(draggedPieceIndex, piece, coords.targetRow, coords.targetCol);
      }

      // Reset drag state
      setDraggedPieceIndex(null);
      setDragPointer(null);
      setHoveredPlacement(null);
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
    };
  }, [draggedPieceIndex, calculateGridCoords]);

  // Execute placement & evaluate line clears
  const placeAndEvaluate = (pieceIndex: number, piece: Piece, row: number, col: number) => {
    // Rich, smooth placement sound
    soundManager.playPlacement();

    // 1. Place piece
    const updatedGrid = placePiece(gridStateRef.current, piece, row, col);

    // Trigger smooth drop bounce animation on placed cells
    const placedCells = new Set<string>();
    for (let r = 0; r < piece.height; r++) {
      for (let c = 0; c < piece.width; c++) {
        if (piece.matrix[r][c] === 1) {
          placedCells.add(`${row + r},${col + c}`);
        }
      }
    }
    setPlacedAnimationCells(placedCells);
    setTimeout(() => {
      setPlacedAnimationCells(null);
    }, 320);

    // Calculate blocks placed count (10 points per single cell: 3 pieces = 30, 9 pieces = 90)
    const cellsCount = piece.matrix.flat().filter(v => v === 1).length;
    const placementPoints = cellsCount * 10;

    // 2. Consume piece from tray
    const updatedPieces = [...piecesStateRef.current];
    updatedPieces[pieceIndex] = null;

    // Check if tray is empty -> spawn 3 new pieces
    const allUsed = updatedPieces.every(p => p === null);
    let nextPieces = updatedPieces;
    if (allUsed) {
      nextPieces = generatePieces(theme);
    }

    // 3. Check for completed lines
    const clearResult = checkAndClearLines(updatedGrid, placementPoints, combo + 1);
    let nextCombo = combo;
    let nextLinesCleared = linesCleared;
    let newScore = score + clearResult.scoreGained;

    if (clearResult.linesCount > 0) {
      // Shatter glass line clear!
      setShatteringCells(clearResult.clearedCells);
      soundManager.playLineClear(clearResult.linesCount);

      nextCombo = combo + 1;
      setMaxCombo(prev => Math.max(prev, nextCombo));
      nextLinesCleared += clearResult.linesCount;

      let blastLabel = 'GOOD!';
      let voiceReaction: 'Good!' | 'Wonderful!' | 'Excellent!' | 'Amazing!' | 'Unbelievable!' | 'Jackpot!' = 'Good!';

      // Progression: Good -> Wonderful -> Excellent -> Amazing -> Unbelievable -> Jackpot
      const effectiveTier = Math.max(clearResult.linesCount, nextCombo);
      if (effectiveTier >= 6 || clearResult.linesCount >= 5) {
        blastLabel = 'JACKPOT!';
        voiceReaction = 'Jackpot!';
      } else if (effectiveTier === 5 || clearResult.linesCount === 4) {
        blastLabel = 'UNBELIEVABLE!';
        voiceReaction = 'Unbelievable!';
      } else if (effectiveTier === 4 || clearResult.linesCount === 3) {
        blastLabel = 'AMAZING!';
        voiceReaction = 'Amazing!';
      } else if (effectiveTier === 3) {
        blastLabel = 'EXCELLENT!';
        voiceReaction = 'Excellent!';
      } else if (effectiveTier === 2 || clearResult.linesCount === 2) {
        blastLabel = 'WONDERFUL!';
        voiceReaction = 'Wonderful!';
      } else {
        blastLabel = 'GOOD!';
        voiceReaction = 'Good!';
      }

      if (nextCombo > 1) {
        blastLabel += ` • ${nextCombo}X COMBO!`;
      }

      // HUGE Gained Score Display!
      setScoreBurst({
        id: `burst-${Date.now()}-${Math.random()}`,
        points: clearResult.scoreGained,
        label: blastLabel,
        isBig: true,
      });

      // Special confetti burst for high-tier Jackpot & Unbelievable
      if (voiceReaction === 'Jackpot!' || voiceReaction === 'Unbelievable!') {
        confetti({
          particleCount: voiceReaction === 'Jackpot!' ? 90 : 50,
          spread: voiceReaction === 'Jackpot!' ? 90 : 65,
          origin: { y: 0.55 },
          colors: ['#fbbf24', '#f59e0b', '#ec4899', '#a855f7', '#3b82f6', '#10b981'],
        });
      }

      // Combo sounds & Voice reactions
      if (nextCombo > 1) {
        soundManager.playCombo(nextCombo);
      }

      // High volume excited woman voice reaction on every block blast!
      soundManager.speakReaction(voiceReaction);

      // Check 5,000 Milestone Crossing
      const oldMilestone = Math.floor(score / 5000);
      const newMilestone = Math.floor(newScore / 5000);
      if (newMilestone > oldMilestone) {
        const nextTheme = getThemeForScore(newScore);
        setTheme(nextTheme);
        soundManager.playMilestone();
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
        });
        // Bonus hint on milestone
        setHintsRemaining(prev => Math.min(prev + 1, 5));
      }
    } else {
      // No line cleared on this move -> reset combo
      nextCombo = 0;

      // Normal placement gained score pop (10 points per piece: 3 pieces = +30, 9 pieces = +90)
      setScoreBurst({
        id: `burst-${Date.now()}-${Math.random()}`,
        points: placementPoints,
        isBig: false,
      });
    }

    // Auto-clear score burst after animation completes
    setTimeout(() => {
      setScoreBurst(null);
    }, 1100);

    // Apply updates
    setGrid(clearResult.newGrid);
    setPieces(nextPieces);
    setScore(newScore);
    setCombo(nextCombo);
    setLinesCleared(nextLinesCleared);
    setSelectedPieceIndex(null);
    setHintCells(null);

    // 4. Check if any valid moves remain
    setTimeout(() => {
      setShatteringCells(null); // Clear shatter state after 2s animation
    }, 2000);

    const hasMoves = hasAnyValidMove(clearResult.newGrid, nextPieces);
    if (!hasMoves) {
      setTimeout(() => {
        soundManager.playGameOver();
        setIsGameOver(true);
      }, 500);
    }
  };

  // Hint powerup
  const handleUseHint = () => {
    if (hintsRemaining <= 0 || isGameOver) return;
    const bestMove = findBestHint(grid, pieces);
    if (bestMove) {
      soundManager.playHint();
      setHintsRemaining(prev => prev - 1);
      setSelectedPieceIndex(bestMove.pieceIndex);
      setHintCells(bestMove.cells);
    }
  };

  // Revival Action
  const handleRevive = () => {
    const { newGrid, clearedCells } = reviveGrid(grid);
    setGrid(newGrid);
    setShatteringCells(clearedCells);
    setCanRevive(false); // Can revive once per game run
    setIsGameOver(false);

    // If tray pieces still couldn't fit, ensure playable pieces
    if (!hasAnyValidMove(newGrid, pieces)) {
      setPieces(generatePieces(theme));
    }

    setTimeout(() => {
      setShatteringCells(null);
    }, 2000);
  };

  // Reset Game
  const handleResetGame = () => {
    const initialTheme = getThemeForScore(0);
    setGrid(createEmptyGrid());
    setScore(0);
    setCombo(0);
    setMaxCombo(0);
    setLinesCleared(0);
    setTheme(initialTheme);
    setPieces(generatePieces(initialTheme));
    setHintsRemaining(3);
    setHintCells(null);
    setCanRevive(true);
    setIsGameOver(false);
    setSelectedPieceIndex(null);
    setHoveredPlacement(null);
  };

  // Toggle Sound FX
  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.setSoundEnabled(next);
  };

  // Toggle Music
  const handleToggleMusic = () => {
    const next = !musicEnabled;
    setMusicEnabled(next);
    soundManager.setMusicEnabled(next);
  };

  // Start Game from Menu
  const handleStartGame = () => {
    setIsInGame(true);
    if (musicEnabled) {
      soundManager.startMusic();
    }
  };

  // Reset High Score
  const handleResetHighScore = () => {
    setHighScore(0);
    try {
      localStorage.removeItem('blockblast_highscore');
    } catch {}
    soundManager.playGameOver();
  };

  // Tap-to-place cell click support
  const handleCellClick = (row: number, col: number) => {
    if (selectedPieceIndex === null || isGameOver) return;
    const piece = piecesStateRef.current[selectedPieceIndex];
    if (!piece) return;

    const targetCol = col - Math.floor((piece.width - 1) / 2);
    const targetRow = row - Math.floor((piece.height - 1) / 2);

    if (canPlacePiece(gridStateRef.current, piece, targetRow, targetCol)) {
      placeAndEvaluate(selectedPieceIndex, piece, targetRow, targetCol);
    }
  };

  const draggedPiece = draggedPieceIndex !== null ? pieces[draggedPieceIndex] : null;

  return (
    <div
      className={`w-screen h-screen overflow-hidden flex flex-col justify-between bg-gradient-to-b ${theme.bgGradient} transition-colors duration-700 select-none touch-none`}
    >
      {!isInGame ? (
        /* Best Good-Looking Main Menu with Sound & Music Options */
        <MainMenu
          highScore={highScore}
          theme={theme}
          onStartGame={handleStartGame}
          onOpenHelp={() => setShowHelpModal(true)}
          onResetHighScore={handleResetHighScore}
        />
      ) : (
        /* In-Game View: ONLY High Score displayed in header */
        <>
          <ScoreBoard
            score={score}
            highScore={highScore}
            combo={combo}
            theme={theme}
            hintsRemaining={hintsRemaining}
            soundEnabled={soundEnabled}
            musicEnabled={musicEnabled}
            onToggleSound={handleToggleSound}
            onToggleMusic={handleToggleMusic}
            onUseHint={handleUseHint}
            onResetGame={handleResetGame}
            onOpenHelp={() => setShowHelpModal(true)}
            onOpenMenu={() => setIsInGame(false)}
          />

          {/* Center: 2D Grid with Solid Milestone Color-Changing Boundary */}
          <main className="flex-1 w-full max-w-xl mx-auto relative overflow-hidden flex items-center justify-center">
            <Grid2D
              grid={grid}
              theme={theme}
              hoveredPlacement={hoveredPlacement}
              hintCells={hintCells}
              shatteringCells={shatteringCells}
              placedAnimationCells={placedAnimationCells}
              boardRef={boardRef}
              onCellClick={handleCellClick}
              scoreBurst={scoreBurst}
            />
          </main>

          {/* Bottom Tray with Blocks */}
          <footer className="w-full pb-3 sm:pb-5">
            <TrayPieces
              pieces={pieces}
              selectedPieceIndex={selectedPieceIndex}
              draggedPieceIndex={draggedPieceIndex}
              onDragStart={handleDragStart}
              onPieceSelect={(idx) => {
                setSelectedPieceIndex(idx);
                setHintCells(null);
              }}
              disabled={isGameOver}
            />
          </footer>
        </>
      )}

      {/* Floating Dragging Piece Representation under finger (Instant 1:1 hardware tracked with spring pickup) */}
      {isInGame && draggedPiece && dragPointer && (
        <div
          className="fixed pointer-events-none z-50 will-change-transform"
          style={{
            left: `${dragPointer.x}px`,
            top: `${dragPointer.y - (window.matchMedia('(pointer: coarse)').matches ? 70 : 35)}px`,
            transform: 'translate(-50%, -50%)',
          }}
        >
          <div
            className="grid gap-1 scale-[1.12] animate-piece-pickup select-none"
            style={{
              filter: 'drop-shadow(0 18px 24px rgba(0, 0, 0, 0.75)) drop-shadow(0 4px 10px rgba(0, 0, 0, 0.5))',
              gridTemplateRows: `repeat(${draggedPiece.height}, minmax(0, 1fr))`,
              gridTemplateColumns: `repeat(${draggedPiece.width}, minmax(0, 1fr))`,
            }}
          >
            {draggedPiece.matrix.map((rowArr, r) =>
              rowArr.map((filled, c) => {
                if (filled === 0) {
                  return <div key={`drag-${r}-${c}`} className="w-7 h-7 sm:w-8 sm:h-8" />;
                }
                return (
                  <div
                    key={`drag-${r}-${c}`}
                    className="w-7 h-7 sm:w-8 sm:h-8 rounded-[6px] relative shadow-xl"
                    style={{
                      backgroundColor: draggedPiece.color,
                      boxShadow: `
                        0 5px 10px rgba(0, 0, 0, 0.6),
                        inset 0 1px 2px rgba(255, 255, 255, 0.8),
                        inset 0 -2px 3px rgba(0, 0, 0, 0.5),
                        0 0 14px ${draggedPiece.color}aa
                      `,
                    }}
                  >
                    <div className="absolute top-0.5 left-0.5 right-0.5 h-2 rounded-t-[4px] bg-white/40 pointer-events-none" />
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Game Over / Revival Modal */}
      {isGameOver && (
        <GameOverModal
          score={score}
          highScore={highScore}
          linesCleared={linesCleared}
          maxCombo={maxCombo}
          canRevive={canRevive}
          onRevive={handleRevive}
          onRestart={handleResetGame}
          onMainMenu={() => {
            setIsGameOver(false);
            setIsInGame(false);
          }}
        />
      )}

      {/* How to Play Rules Modal */}
      {showHelpModal && (
        <HowToPlayModal onClose={() => setShowHelpModal(false)} />
      )}
    </div>
  );
}
