import React, { useState, useEffect } from 'react';
import { Trophy, Zap, RotateCcw, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../audio/soundManager';

interface GameOverModalProps {
  score: number;
  highScore: number;
  linesCleared: number;
  maxCombo: number;
  canRevive: boolean;
  onRevive: () => void;
  onRestart: () => void;
  onMainMenu?: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  linesCleared,
  maxCombo,
  canRevive,
  onRevive,
  onRestart,
  onMainMenu,
}) => {
  const [countdown, setCountdown] = useState<number>(6);
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adProgress, setAdProgress] = useState(0);

  const isNewRecord = score > 0 && score >= highScore;

  useEffect(() => {
    if (isNewRecord) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  }, [isNewRecord]);

  // Countdown timer for revival offer
  useEffect(() => {
    if (!canRevive || isWatchingAd) return;
    if (countdown <= 0) return;

    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown, canRevive, isWatchingAd]);

  const handleStartRevival = () => {
    setIsWatchingAd(true);
    soundManager.playHint();
    let current = 0;
    const interval = setInterval(() => {
      current += 25;
      setAdProgress(current);
      if (current >= 100) {
        clearInterval(interval);
        soundManager.playRevive();
        soundManager.speakReaction('You can do it!');
        onRevive();
      }
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none">
      <div className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-700/80 p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto scroll-smooth overscroll-contain touch-pan-y animate-in fade-in zoom-in-95 duration-200">
        {/* Glow ambient background */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Revival Offer State */}
        {canRevive && countdown > 0 && !isWatchingAd && (
          <div className="flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-3 shadow-lg shadow-amber-500/10 animate-bounce">
              <Zap className="w-8 h-8" />
            </div>

            <h2 className="text-2xl font-black font-game tracking-wider uppercase text-white mb-1">
              Out of Moves!
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              Revive now to shatter center blocks and preserve your{' '}
              <span className="text-amber-400 font-bold">{score.toLocaleString()}</span> score!
            </p>

            {/* Countdown Badge */}
            <div className="mb-5 flex items-center gap-2">
              <span className="text-xs text-slate-400 font-medium">Expires in</span>
              <span className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-game font-black text-amber-400 text-sm">
                {countdown}
              </span>
            </div>

            <button
              onClick={handleStartRevival}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 active:scale-98 text-slate-950 font-black font-game tracking-wider uppercase text-sm shadow-xl shadow-amber-500/30 flex items-center justify-center gap-2 mb-2 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Free Ad Revival</span>
            </button>

            <button
              onClick={() => setCountdown(0)}
              className="py-2 text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              No thanks, end game
            </button>
          </div>
        )}

        {/* Ad In Progress Animation */}
        {isWatchingAd && (
          <div className="flex flex-col items-center text-center py-4">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 mb-4 animate-spin">
              <Zap className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold font-game uppercase text-white mb-1">
              Preparing Revival Blast...
            </h3>
            <p className="text-xs text-slate-400 mb-4">Shattering blocked cells in 3... 2... 1...</p>
            <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${adProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Final Game Over Summary (when countdown expired or declined) */}
        {(!canRevive || countdown <= 0) && !isWatchingAd && (
          <div className="flex flex-col items-center text-center">
            {isNewRecord ? (
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-3 shadow-lg shadow-amber-500/20">
                <Trophy className="w-8 h-8" />
              </div>
            ) : (
              <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3 shadow-lg shadow-rose-500/10">
                <RotateCcw className="w-7 h-7" />
              </div>
            )}

            <h2 className="text-2xl font-black font-game tracking-wider uppercase text-white mb-1">
              {isNewRecord ? 'New Best Score!' : 'Game Over'}
            </h2>
            <p className="text-xs text-slate-400 mb-5">
              {isNewRecord ? 'Incredible run! You set a new record!' : 'Great effort! Want to try again?'}
            </p>

            {/* Score Cards */}
            <div className="w-full grid grid-cols-2 gap-2.5 mb-5">
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3 flex flex-col items-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Final Score</span>
                <span className="text-2xl font-black font-game text-white">{score.toLocaleString()}</span>
              </div>
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3 flex flex-col items-center">
                <span className="text-[10px] text-amber-400 uppercase font-semibold">Best Score</span>
                <span className="text-2xl font-black font-game text-amber-300">{highScore.toLocaleString()}</span>
              </div>
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-2.5 flex flex-col items-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Lines Blasted</span>
                <span className="text-lg font-black font-game text-cyan-400">{linesCleared}</span>
              </div>
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-2.5 flex flex-col items-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Max Combo</span>
                <span className="text-lg font-black font-game text-orange-400">{maxCombo}X</span>
              </div>
            </div>

            <button
              onClick={onRestart}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-98 text-white font-black font-game tracking-wider uppercase text-sm shadow-xl shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer mb-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Play Again</span>
            </button>

            {onMainMenu && (
              <button
                onClick={onMainMenu}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
              >
                Return to Main Menu
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
