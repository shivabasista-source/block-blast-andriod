import React, { useState } from 'react';
import {
  Play,
  Trophy,
  Volume2,
  VolumeX,
  Music,
  HelpCircle,
  Sparkles,
  Smartphone,
  MessageSquare,
  RotateCcw,
} from 'lucide-react';
import { soundManager } from '../audio/soundManager';
import { ThemeConfig } from '../types/game';

interface MainMenuProps {
  highScore: number;
  theme: ThemeConfig;
  onStartGame: () => void;
  onOpenHelp: () => void;
  onResetHighScore: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  highScore,
  theme,
  onStartGame,
  onOpenHelp,
  onResetHighScore,
}) => {
  // Volume and sound state
  const [sfxVolume, setSfxVolume] = useState<number>(() => soundManager.sfxVolume);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => soundManager.soundEnabled);
  const [musicVolume, setMusicVolume] = useState<number>(() => soundManager.musicVolume);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(() => soundManager.musicEnabled);
  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(() => soundManager.vibrationEnabled);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(() => soundManager.voiceEnabled);

  const [activeTab, setActiveTab] = useState<'play' | 'audio'>('play');

  const handleSfxChange = (val: number) => {
    setSfxVolume(val);
    soundManager.setSfxVolume(val);
    if (val > 0 && !soundEnabled) {
      setSoundEnabled(true);
      soundManager.setSoundEnabled(true);
    }
    soundManager.playHoverSnap(true);
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.setSoundEnabled(next);
    if (next) soundManager.playHoverSnap(true);
  };

  const handleMusicChange = (val: number) => {
    setMusicVolume(val);
    soundManager.setMusicVolume(val);
    if (val > 0 && !musicEnabled) {
      setMusicEnabled(true);
      soundManager.setMusicEnabled(true);
    }
  };

  const toggleMusic = () => {
    const next = !musicEnabled;
    setMusicEnabled(next);
    soundManager.setMusicEnabled(next);
  };

  const toggleVibration = () => {
    const next = !vibrationEnabled;
    setVibrationEnabled(next);
    soundManager.setVibrationEnabled(next);
    if (next) soundManager.vibrate(30);
  };

  const toggleVoice = () => {
    const next = !voiceEnabled;
    setVoiceEnabled(next);
    soundManager.setVoiceEnabled(next);
    if (next) soundManager.speakReaction('Good!');
  };

  const handlePlayClick = () => {
    soundManager.playPlacement();
    onStartGame();
  };

  return (
    <div className="w-full h-full flex items-center justify-center p-4 relative overflow-y-auto scroll-smooth overscroll-contain touch-pan-y select-none">
      {/* Decorative ambient background glowing elements */}
      <div
        className="absolute top-1/4 -left-20 w-72 h-72 rounded-full blur-[100px] pointer-events-none opacity-30 transition-colors duration-700"
        style={{ backgroundColor: theme.solidBoundaryColor }}
      />
      <div
        className="absolute bottom-1/4 -right-20 w-72 h-72 rounded-full blur-[100px] pointer-events-none opacity-25 transition-colors duration-700"
        style={{ backgroundColor: theme.solidBoundaryColor }}
      />

      {/* Main Glassmorphic Card Container */}
      <div className="w-full max-w-sm rounded-3xl bg-slate-900/90 border border-slate-700/80 p-6 sm:p-7 shadow-2xl backdrop-blur-xl relative z-10 flex flex-col items-center animate-in fade-in zoom-in-95 duration-300">
        {/* Animated Brand Logo Icon */}
        <div className="relative mb-3 group cursor-pointer" onClick={() => soundManager.playHoverSnap(true)}>
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-700 transform group-hover:scale-105"
            style={{
              backgroundColor: theme.solidBoundaryColor,
              boxShadow: `0 0 25px ${theme.solidBoundaryColor}80`,
            }}
          >
            <div className="grid grid-cols-2 gap-1.5 p-2 w-12 h-12">
              <div className="rounded-md bg-slate-950/80 border border-white/20" />
              <div className="rounded-md bg-slate-950/80 border border-white/20" />
              <div className="rounded-md bg-slate-950/80 border border-white/20" />
              <div className="rounded-md bg-white/90 shadow-sm" />
            </div>
            <div className="absolute top-0.5 left-0.5 right-0.5 h-1.5 rounded-t-[3px] bg-white/40 pointer-events-none" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-black font-game tracking-wider uppercase text-center text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-slate-300 drop-shadow-md">
          Block Blast
        </h1>
        <div className="flex items-center gap-2 mt-1 mb-5">
          <span
            className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase text-slate-950 font-game tracking-wider shadow-sm transition-colors duration-700"
            style={{ backgroundColor: theme.solidBoundaryColor }}
          >
            Endless Puzzle
          </span>
          <span className="text-[11px] text-slate-400 font-medium">Cyber AI Edition</span>
        </div>

        {/* High Score Trophy Showcase */}
        <div className="w-full rounded-2xl bg-gradient-to-r from-slate-950/80 via-slate-900/90 to-slate-950/80 border border-amber-500/40 p-3.5 mb-5 flex items-center justify-between shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 shadow-md shadow-amber-500/30">
              <Trophy className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                <span>Record Best Score</span>
                <Sparkles className="w-3 h-3 text-amber-300" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-game text-amber-300 tracking-tight">
                {highScore.toLocaleString()}
              </div>
            </div>
          </div>
          {highScore > 0 && (
            <button
              onClick={onResetHighScore}
              title="Reset Record"
              className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Navigation Tabs (Play / Audio Options) */}
        <div className="w-full flex rounded-xl bg-slate-950/80 p-1 border border-slate-800 mb-5">
          <button
            onClick={() => setActiveTab('play')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold font-game uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'play'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Start Run
          </button>
          <button
            onClick={() => setActiveTab('audio')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold font-game uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'audio'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Sound Options</span>
          </button>
        </div>

        {/* TAB 1: PLAY & QUICK ACTIONS */}
        {activeTab === 'play' && (
          <div className="w-full space-y-3">
            <button
              onClick={handlePlayClick}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-500 hover:from-emerald-300 hover:to-cyan-400 text-slate-950 font-black font-game text-lg tracking-wider uppercase shadow-xl shadow-cyan-500/25 active:scale-98 transition-all flex items-center justify-center gap-3 cursor-pointer group"
            >
              <Play className="w-6 h-6 fill-current group-hover:scale-110 transition-transform" />
              <span>Play Game</span>
            </button>

            <button
              onClick={onOpenHelp}
              className="w-full py-3 px-4 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/80 text-slate-300 font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span>How to Play & Rules</span>
            </button>
          </div>
        )}

        {/* TAB 2: DETAILED SOUND & MUSIC CONTROLS */}
        {activeTab === 'audio' && (
          <div className="w-full space-y-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
            {/* SFX Volume Slider */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  <span>Block Move & SFX</span>
                </span>
                <span className="font-mono text-emerald-400 text-xs font-bold">
                  {soundEnabled ? `${Math.round(sfxVolume * 100)}%` : 'MUTED'}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={toggleSound}
                  className={`p-1.5 rounded-lg border text-xs cursor-pointer transition-all ${
                    soundEnabled ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-500'
                  }`}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={soundEnabled ? sfxVolume : 0}
                  onChange={(e) => handleSfxChange(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
                />
              </div>
            </div>

            {/* Cool Background Music Slider & Toggle */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Music className="w-4 h-4 text-cyan-400" />
                  <span>Cool Synthwave Music</span>
                </span>
                <span className="font-mono text-cyan-400 text-xs font-bold">
                  {musicEnabled ? `${Math.round(musicVolume * 100)}%` : 'MUTED'}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={toggleMusic}
                  className={`p-1.5 rounded-lg border text-xs cursor-pointer transition-all ${
                    musicEnabled ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300' : 'bg-slate-800 border-slate-700 text-slate-500'
                  }`}
                >
                  <Music className="w-4 h-4" />
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={musicEnabled ? musicVolume : 0}
                  onChange={(e) => handleMusicChange(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>

            {/* Feature Toggles (Voice cheer & Haptics) */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
              <button
                onClick={toggleVoice}
                className={`p-2 rounded-xl border flex items-center justify-between text-xs cursor-pointer transition-all ${
                  voiceEnabled ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/40 border-slate-700/40 text-slate-500'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Voice Cheer</span>
                </span>
                <span className="text-[10px] font-bold">{voiceEnabled ? 'ON' : 'OFF'}</span>
              </button>

              <button
                onClick={toggleVibration}
                className={`p-2 rounded-xl border flex items-center justify-between text-xs cursor-pointer transition-all ${
                  vibrationEnabled ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' : 'bg-slate-800/40 border-slate-700/40 text-slate-500'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Haptics</span>
                </span>
                <span className="text-[10px] font-bold">{vibrationEnabled ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Target goal reminder */}
        <div className="mt-5 text-[11px] text-slate-400 text-center flex items-center gap-1.5">
          <span
            className="w-2.5 h-2.5 rounded-full inline-block animate-pulse"
            style={{ backgroundColor: theme.solidBoundaryColor }}
          />
          <span>Reach Target: 5,000 → 10,000 → 15,000 to advance!</span>
        </div>
      </div>
    </div>
  );
};
