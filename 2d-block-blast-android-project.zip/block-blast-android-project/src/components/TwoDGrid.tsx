import React, { useRef, useEffect, useState } from 'react';
import { Grid, Piece, ThemeConfig } from '../types/game';
import { GRID_SIZE } from '../utils/gameLogic';

interface TwoDGridProps {
  grid: Grid;
  theme: ThemeConfig;
  hoveredPlacement: {
    piece: Piece;
    row: number;
    col: number;
    isValid: boolean;
  } | null;
  hintCells: [number, number][] | null;
  shatteringCells: { row: number; col: number; color: string }[] | null;
  onCellClick?: (row: number, col: number) => void;
  gridRef: React.RefObject<HTMLDivElement | null>;
}

// 2D Glass Shard Particle
interface Shard2D {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vRot: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  points: { x: number; y: number }[];
}

const ROW_LABELS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
const COL_LABELS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];

export const TwoDGrid: React.FC<TwoDGridProps> = ({
  grid,
  theme,
  hoveredPlacement,
  hintCells,
  shatteringCells,
  onCellClick,
  gridRef,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const shardsRef = useRef<Shard2D[]>([]);
  const animFrameRef = useRef<number>(0);
  const [boundaryProgress, setBoundaryProgress] = useState(0);

  // Animate the perimeter photon runners
  useEffect(() => {
    let startTime = performance.now();
    let frameId: number;

    const loop = (now: number) => {
      const elapsed = (now - startTime) / 1000;
      setBoundaryProgress((elapsed * 0.28) % 1);
      frameId = requestAnimationFrame(loop);
    };

    frameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameId);
  }, []);

  // 2D Glass-Shattering Canvas Particle System
  useEffect(() => {
    if (!shatteringCells || shatteringCells.length === 0 || !gridRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const rect = gridRef.current.getBoundingClientRect();

    canvas.width = rect.width;
    canvas.height = rect.height;

    const cellWidth = rect.width / GRID_SIZE;
    const cellHeight = rect.height / GRID_SIZE;

    const newShards: Shard2D[] = [];

    shatteringCells.forEach(cell => {
      const centerX = (cell.col + 0.5) * cellWidth;
      const centerY = (cell.row + 0.5) * cellHeight;
      const count = 12; // 12 glass shards per block for explosive effect

      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 120 + Math.random() * 260; // pixels per second
        const vx = Math.cos(angle) * speed;
        const vy = Math.sin(angle) * speed - 60; // upward bias

        // Create random triangular or polygonal glass shard
        const s = 4 + Math.random() * 8;
        const points = [
          { x: 0, y: -s },
          { x: s * (0.6 + Math.random() * 0.5), y: s * (0.4 + Math.random() * 0.4) },
          { x: -s * (0.6 + Math.random() * 0.5), y: s * (0.5 + Math.random() * 0.5) },
        ];

        newShards.push({
          x: centerX + (Math.random() - 0.5) * (cellWidth * 0.6),
          y: centerY + (Math.random() - 0.5) * (cellHeight * 0.6),
          vx,
          vy,
          rot: Math.random() * Math.PI * 2,
          vRot: (Math.random() - 0.5) * 16,
          size: s,
          color: cell.color,
          alpha: 1,
          life: 0,
          maxLife: 0.26 + Math.random() * 0.12, // 0.26 - 0.38 seconds
          points,
        });
      }
    });

    shardsRef.current.push(...newShards);
  }, [shatteringCells, gridRef]);

  // Particle render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();

    const tick = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (shardsRef.current.length > 0) {
        const aliveShards: Shard2D[] = [];

        for (const shard of shardsRef.current) {
          shard.life += dt;
          if (shard.life < shard.maxLife) {
            // Physics: velocity + gravity
            shard.vy += 450 * dt;
            shard.x += shard.vx * dt;
            shard.y += shard.vy * dt;
            shard.rot += shard.vRot * dt;

            // Fade & scale progress
            const progress = shard.life / shard.maxLife;
            shard.alpha = Math.max(0, 1 - progress);
            const scale = Math.max(0.1, 1 - progress * 0.6);

            // Draw glass shard
            ctx.save();
            ctx.translate(shard.x, shard.y);
            ctx.rotate(shard.rot);
            ctx.scale(scale, scale);

            ctx.fillStyle = shard.color;
            ctx.globalAlpha = shard.alpha;
            ctx.shadowColor = shard.color;
            ctx.shadowBlur = 8;

            ctx.beginPath();
            ctx.moveTo(shard.points[0].x, shard.points[0].y);
            for (let i = 1; i < shard.points.length; i++) {
              ctx.lineTo(shard.points[i].x, shard.points[i].y);
            }
            ctx.closePath();
            ctx.fill();

            // Specular glass shine edge
            ctx.strokeStyle = '#ffffff';
            ctx.globalAlpha = shard.alpha * 0.8;
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.restore();
            aliveShards.push(shard);
          }
        }

        shardsRef.current = aliveShards;
      }

      animFrameRef.current = requestAnimationFrame(tick);
    };

    animFrameRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, []);

  // Compute ghost preview map for quick lookup
  const ghostMap = new Map<string, { isValid: boolean }>();
  if (hoveredPlacement) {
    const { piece, row, col, isValid } = hoveredPlacement;
    for (let r = 0; r < piece.height; r++) {
      for (let c = 0; c < piece.width; c++) {
        if (piece.matrix[r][c] === 1) {
          ghostMap.set(`${row + r},${col + c}`, { isValid });
        }
      }
    }
  }

  // Compute hint map
  const hintMap = new Set<string>();
  if (hintCells) {
    hintCells.forEach(([r, c]) => hintMap.add(`${r},${c}`));
  }

  // Photon runner positions around perimeter (0 to 1)
  const getRunnerStyle = (offset: number) => {
    const p = (boundaryProgress + offset) % 1;
    let top = 0;
    let left = 0;

    if (p < 0.25) {
      // Top edge (left to right)
      left = (p / 0.25) * 100;
      top = 0;
    } else if (p < 0.5) {
      // Right edge (top to bottom)
      left = 100;
      top = ((p - 0.25) / 0.25) * 100;
    } else if (p < 0.75) {
      // Bottom edge (right to left)
      left = (1 - (p - 0.5) / 0.25) * 100;
      top = 100;
    } else {
      // Left edge (bottom to top)
      left = 0;
      top = (1 - (p - 0.75) / 0.25) * 100;
    }

    return {
      left: `${left}%`,
      top: `${top}%`,
      transform: 'translate(-50%, -50%)',
      backgroundColor: '#ffffff',
      boxShadow: `0 0 10px #ffffff, 0 0 16px ${theme.boardGlowColor}`,
    };
  };

  return (
    <div className="relative w-full max-w-[min(92vw,440px)] mx-auto p-3 sm:p-4 select-none touch-none">
      {/* Volumetric Underglow Ambient Aura */}
      <div
        className="absolute inset-2 rounded-[36px] blur-2xl opacity-40 transition-all duration-700 pointer-events-none"
        style={{ backgroundColor: theme.boardGlowColor }}
      />

      {/* Main AI Cyber Chassis Container */}
      <div
        className="relative rounded-[28px] bg-slate-950/95 border-2 p-3 sm:p-4 shadow-2xl transition-all duration-700 backdrop-blur-xl"
        style={{
          borderColor: theme.accentColor + '80',
          boxShadow: `
            0 0 24px ${theme.boardGlowColor}33,
            inset 0 0 20px rgba(0, 0, 0, 0.8),
            inset 0 1px 1px rgba(255, 255, 255, 0.15)
          `,
        }}
      >
        {/* Animated Perimeter Photon Runners */}
        <div className="absolute inset-1.5 rounded-[24px] pointer-events-none overflow-hidden">
          <div className="absolute w-2 h-2 rounded-full" style={getRunnerStyle(0)} />
          <div className="absolute w-2 h-2 rounded-full" style={getRunnerStyle(0.25)} />
          <div className="absolute w-2 h-2 rounded-full" style={getRunnerStyle(0.5)} />
          <div className="absolute w-2 h-2 rounded-full" style={getRunnerStyle(0.75)} />
        </div>

        {/* 4 Cyber Corner Brackets with Reactor Nodes */}
        {/* Top-Left Corner */}
        <div className="absolute -top-1.5 -left-1.5 flex items-center justify-center pointer-events-none">
          <div
            className="w-5 h-5 rounded-tl-xl border-t-2 border-l-2 transition-colors duration-500"
            style={{ borderColor: theme.accentColor }}
          />
          <div
            className="absolute w-2 h-2 rounded-full animate-ping opacity-75"
            style={{ backgroundColor: theme.boardGlowColor }}
          />
          <div
            className="absolute w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: theme.boardGlowColor }}
          />
        </div>

        {/* Top-Right Corner */}
        <div className="absolute -top-1.5 -right-1.5 flex items-center justify-center pointer-events-none">
          <div
            className="w-5 h-5 rounded-tr-xl border-t-2 border-r-2 transition-colors duration-500"
            style={{ borderColor: theme.accentColor }}
          />
          <div
            className="absolute w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: theme.boardGlowColor }}
          />
        </div>

        {/* Bottom-Left Corner */}
        <div className="absolute -bottom-1.5 -left-1.5 flex items-center justify-center pointer-events-none">
          <div
            className="w-5 h-5 rounded-bl-xl border-b-2 border-l-2 transition-colors duration-500"
            style={{ borderColor: theme.accentColor }}
          />
          <div
            className="absolute w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: theme.boardGlowColor }}
          />
        </div>

        {/* Bottom-Right Corner */}
        <div className="absolute -bottom-1.5 -right-1.5 flex items-center justify-center pointer-events-none">
          <div
            className="w-5 h-5 rounded-br-xl border-b-2 border-r-2 transition-colors duration-500"
            style={{ borderColor: theme.accentColor }}
          />
          <div
            className="absolute w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: theme.boardGlowColor }}
          />
        </div>

        {/* Top Tech Telemetry Strip */}
        <div className="flex items-center justify-between text-[9px] sm:text-[10px] font-mono text-slate-400 mb-1.5 px-1 tracking-wider uppercase">
          <div className="flex items-center gap-1.5">
            <span
              className="w-1.5 h-1.5 rounded-full animate-pulse"
              style={{ backgroundColor: theme.boardGlowColor }}
            />
            <span className="font-bold text-white tracking-widest">AI MATRIX // 10×10</span>
          </div>
          <div className="text-slate-500">GRID: 100 CELLS</div>
        </div>

        {/* Column Laser Coordinate Labels (1-10) */}
        <div className="grid grid-cols-10 gap-1 sm:gap-1.5 text-center text-[8px] sm:text-[9px] font-mono text-slate-500 mb-1 pointer-events-none font-bold">
          {COL_LABELS.map(num => (
            <div key={`col-${num}`}>{num}</div>
          ))}
        </div>

        {/* 10x10 Interactive Grid Board Area */}
        <div className="relative">
          <div
            ref={gridRef}
            className="grid grid-cols-10 gap-1 sm:gap-1.5 aspect-square w-full rounded-2xl bg-slate-900/90 border border-slate-800/90 p-1.5 shadow-inner"
            style={{
              boxShadow: `inset 0 0 15px rgba(0, 0, 0, 0.9)`,
            }}
          >
            {grid.map((rowArr, r) =>
              rowArr.map((color, c) => {
                const key = `${r},${c}`;
                const ghost = ghostMap.get(key);
                const isHint = hintMap.has(key);
                const isFilled = color !== null;

                // Determine Cell Visual State
                let cellBg = 'bg-slate-950/70 border border-slate-800/60';
                let cellContent: React.ReactNode = null;
                let cellShadow = '';

                if (isFilled) {
                  // Solid 2D Glossy Beveled Block
                  cellBg = '';
                  cellShadow = `
                    0 3px 6px rgba(0, 0, 0, 0.6),
                    inset 0 1.5px 2px rgba(255, 255, 255, 0.65),
                    inset 0 -2px 3px rgba(0, 0, 0, 0.5),
                    0 0 10px ${color}66
                  `;
                  cellContent = (
                    <div
                      className="w-full h-full rounded-[6px] sm:rounded-[7px] relative transition-transform active:scale-95"
                      style={{
                        backgroundColor: color,
                        boxShadow: cellShadow,
                      }}
                    >
                      {/* Top Specular Shine Glass Bar */}
                      <div className="absolute top-0.5 left-0.5 right-0.5 h-1.5 sm:h-2 rounded-t-[5px] bg-white/40 pointer-events-none" />
                    </div>
                  );
                } else if (ghost) {
                  // Ghost Placement Preview
                  const ghostColor = ghost.isValid ? '#22c55e' : '#ef4444';
                  cellBg = ghost.isValid ? 'bg-emerald-500/35 border-2 border-emerald-400' : 'bg-rose-500/35 border-2 border-rose-500';
                  cellContent = (
                    <div
                      className="w-full h-full rounded-[6px] sm:rounded-[7px] animate-pulse"
                      style={{
                        boxShadow: `0 0 12px ${ghostColor}`,
                      }}
                    />
                  );
                } else if (isHint) {
                  // Golden Pulsing Hint Cell
                  cellBg = 'bg-amber-500/25 border-2 border-amber-400';
                  cellContent = (
                    <div className="w-full h-full rounded-[6px] sm:rounded-[7px] animate-pulse bg-amber-400/20" />
                  );
                } else {
                  // Empty Cell with micro tech crosshair
                  cellContent = (
                    <div className="w-1 h-1 sm:w-1.5 sm:h-1.5 rounded-full bg-slate-800/80 pointer-events-none" />
                  );
                }

                return (
                  <div
                    key={key}
                    onClick={() => onCellClick?.(r, c)}
                    className={`aspect-square rounded-[6px] sm:rounded-[7px] flex items-center justify-center relative cursor-pointer select-none transition-all duration-75 overflow-hidden ${cellBg}`}
                  >
                    {cellContent}
                  </div>
                );
              })
            )}
          </div>

          {/* Glass-Shattering Canvas Overlay */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 pointer-events-none z-20"
          />
        </div>

        {/* Bottom Tech Status & Laser Hash Marks */}
        <div className="flex items-center justify-between text-[9px] font-mono text-slate-500 mt-1.5 px-1">
          <span className="flex items-center gap-1">
            <span
              className="w-1.5 h-1.5 rounded-full inline-block"
              style={{ backgroundColor: theme.accentColor }}
            />
            <span>{theme.name} PHASE</span>
          </span>
          <span className="tracking-widest">SNAP-TO-GRID // READY</span>
        </div>
      </div>
    </div>
  );
};
