import React from 'react';
import { X, Sparkles, Layers, Zap, Award } from 'lucide-react';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700/80 p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto scroll-smooth overscroll-contain touch-pan-y animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black font-game uppercase tracking-wide text-white">
              How To Play
            </h2>
            <p className="text-xs text-slate-400">Rules & Strategy Guide</p>
          </div>
        </div>

        <div className="space-y-3.5 text-xs text-slate-300">
          <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm mb-0.5">1. Drag & Place Blocks</h3>
              <p className="text-slate-400 leading-relaxed">
                Touch or click any shape from the bottom tray and drag it onto the puzzle grid. Each single block piece placed awards <strong className="text-cyan-400">10 points</strong> (e.g. 3-piece shape = 30 pts, 9-piece shape = 90 pts).
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm mb-0.5">2. Blast Lines Like Glass</h3>
              <p className="text-slate-400 leading-relaxed">
                Fill any horizontal or vertical line to clear it instantly in a glass-shattering explosion. Clear multiple lines at once for huge point multipliers!
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm mb-0.5">3. Multi-Line & Block Scoring</h3>
              <ul className="text-slate-400 list-disc list-inside mt-1 space-y-0.5">
                <li><strong className="text-white">Placed Blocks:</strong> 10 Points per cell (3 pieces = 30, 9 pieces = 90)</li>
                <li><strong className="text-white">1 Line Clear:</strong> 200 Points</li>
                <li><strong className="text-white">2 Lines Clear:</strong> 400 Points</li>
                <li><strong className="text-white">3 Lines Clear:</strong> 600 Points</li>
                <li><strong className="text-white">4+ Lines Clear:</strong> 800+ Points (+200 per line)</li>
                <li><strong className="text-amber-400">Combos:</strong> Consecutive line clears stack extra streak bonuses!</li>
              </ul>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm mb-0.5">4. Color Themes Every 5,000 Pts</h3>
              <p className="text-slate-400 leading-relaxed">
                Crossing every 5,000-point milestone transforms the 3D block palette, grid neon borders, board lighting, and ambient glow indefinitely!
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-5 w-full py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 active:scale-98 text-slate-950 font-black font-game uppercase tracking-wider text-xs shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
        >
          Got It, Let's Play!
        </button>
      </div>
    </div>
  );
};
