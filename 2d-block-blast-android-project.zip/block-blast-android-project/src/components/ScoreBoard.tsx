import React from 'react';
import { Trophy, Volume2, VolumeX, Lightbulb, RotateCcw, HelpCircle, Menu, Music } from 'lucide-react';
import { ThemeConfig } from '../types/game';

interface ScoreBoardProps {
  score: number;
  highScore: number;
  combo: number;
  theme: ThemeConfig;
  hintsRemaining: number;
  soundEnabled: boolean;
  musicEnabled?: boolean;
  onToggleSound: () => void;
  onToggleMusic?: () => void;
  onUseHint: () => void;
  onResetGame: () => void;
  onOpenHelp: () => void;
  onOpenMenu: () => void;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  score,
  highScore,
  combo,
  theme,
  hintsRemaining,
  soundEnabled,
  musicEnabled = false,
  onToggleSound,
  onToggleMusic,
  onUseHint,
  onResetGame,
  onOpenHelp,
  onOpenMenu,
}) => {
  const currentTier = Math.floor(score / 5000) + 1;
  const currentMilestoneScore = score % 5000;
  const progressPercent = Math.min(100, Math.floor((currentMilestoneScore / 5000) * 100));
  const nextTarget = currentTier * 5000;

  return (
    <header className="w-full max-w-xl mx-auto px-4 pt-3 pb-1 select-none">
      {/* Top Bar: Title & Controls */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenMenu}
            title="Main Menu"
            className="w-8 h-8 rounded-xl flex items-center justify-center font-bold text-sm shadow-md cursor-pointer transition-transform active:scale-95"
            style={{
              backgroundColor: theme.solidBoundaryColor,
              color: '#000',
              boxShadow: `0 0 12px ${theme.solidBoundaryColor}88`,
            }}
          >
            <Menu className="w-4 h-4 stroke-[2.5]" />
          </button>
          <div>
            <h1 className="text-base sm:text-lg font-black tracking-wider uppercase font-game leading-tight flex items-center gap-1.5 text-white">
              <span>Block Blast</span>
            </h1>
            <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
              <span
                className="w-2 h-2 rounded-full inline-block transition-colors duration-700"
                style={{ backgroundColor: theme.solidBoundaryColor }}
              />
              <span>{theme.name}</span>
            </div>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          <button
            onClick={onUseHint}
            disabled={hintsRemaining <= 0}
            title="Get Hint"
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all shadow-sm ${
              hintsRemaining > 0
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 hover:bg-amber-500/30 active:scale-95 cursor-pointer'
                : 'bg-slate-800/40 border-slate-700/40 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>Hint ({hintsRemaining})</span>
          </button>

          {/* SFX Toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute SFX' : 'Enable SFX'}
            className={`p-2 rounded-xl border transition-all text-xs cursor-pointer ${
              soundEnabled
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                : 'bg-slate-800/40 border-slate-700/40 text-slate-400'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Cool Background Music Toggle */}
          {onToggleMusic && (
            <button
              onClick={onToggleMusic}
              title={musicEnabled ? 'Pause Music' : 'Play Music'}
              className={`p-2 rounded-xl border transition-all text-xs cursor-pointer ${
                musicEnabled
                  ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                  : 'bg-slate-800/40 border-slate-700/40 text-slate-500'
              }`}
            >
              <Music className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onResetGame}
            title="Restart Game"
            className="p-2 rounded-xl border border-slate-800 bg-slate-900/60 text-slate-300 hover:bg-slate-800 transition-all active:scale-95 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenHelp}
            title="How to Play"
            className="p-2 rounded-xl border border-slate-800 bg-slate-900/60 text-slate-300 hover:bg-slate-800 transition-all active:scale-95 cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 
        High Score Panel (ONLY SHOW HIGH SCORE IN GAME as requested)
      */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/80 to-slate-950/90 border border-slate-800 p-2.5 px-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-md shadow-amber-500/10">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span>High Score</span>
              <span className="text-[10px] text-slate-500 font-normal">All Time</span>
            </div>
            <div className="text-2xl sm:text-3xl font-black font-game tracking-tight text-amber-300">
              {Math.max(score, highScore).toLocaleString()}
            </div>
          </div>
        </div>

        {combo > 1 && (
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-black font-game text-orange-400 bg-orange-500/20 border border-orange-500/40 px-2.5 py-1 rounded-full animate-bounce shadow-md">
              {combo}X STREAK!
            </span>
          </div>
        )}
      </div>

      {/* Target Progress Bar (5,000 -> 10,000 -> 15,000 accordingly) */}
      <div className="mt-2 bg-slate-900/80 border border-slate-800/80 rounded-xl p-2 px-3 flex flex-col gap-1.5 shadow-sm">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-bold font-game uppercase tracking-wider text-slate-300">
            <span>Target:</span>
            <span
              className="px-2 py-0.5 rounded-md font-black shadow-sm transition-colors duration-700"
              style={{ backgroundColor: theme.solidBoundaryColor, color: '#020617' }}
            >
              {nextTarget.toLocaleString()}
            </span>
          </div>
          <span className="text-slate-400 font-mono text-[11px]">
            {score.toLocaleString()} / {nextTarget.toLocaleString()}
          </span>
        </div>
        <div className="w-full h-2 bg-slate-800/90 rounded-full overflow-hidden relative">
          <div
            className="h-full rounded-full transition-all duration-300 ease-out"
            style={{
              width: `${progressPercent}%`,
              backgroundColor: theme.solidBoundaryColor,
              boxShadow: `0 0 10px ${theme.solidBoundaryColor}`,
            }}
          />
        </div>
      </div>
    </header>
  );
};
