import React, { useRef, useEffect, useCallback } from 'react';
import { Grid, Piece, ThemeConfig } from '../types/game';
import { GRID_SIZE } from '../utils/gameLogic';

export interface ScoreBurst {
  id: string;
  points: number;
  label?: string;
  isBig: boolean;
}

interface Grid2DProps {
  grid: Grid;
  theme: ThemeConfig;
  hoveredPlacement: {
    piece: Piece;
    row: number;
    col: number;
    isValid: boolean;
  } | null;
  hintCells: [number, number][] | null;
  shatteringCells: { row: number; col: number; color: string }[] | null;
  placedAnimationCells?: Set<string> | null;
  boardRef: React.RefObject<HTMLDivElement | null>;
  onCellClick?: (row: number, col: number) => void;
  scoreBurst?: ScoreBurst | null;
}

interface Particle2D {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rotation: number;
  vRot: number;
  color: string;
  points: [number, number][]; // Sharp triangular shard polygon
  life: number;
  maxLife: number;
}

export const Grid2D: React.FC<Grid2DProps> = ({
  grid,
  theme,
  hoveredPlacement,
  hintCells,
  shatteringCells,
  placedAnimationCells,
  boardRef,
  onCellClick,
  scoreBurst,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle2D[]>([]);
  const animFrameIdRef = useRef<number>(0);
  const isLoopRunningRef = useRef<boolean>(false);
  const lastTimeRef = useRef<number>(0);

  // Particle Animation Loop
  const renderParticles = useCallback((now: number) => {
    if (!canvasRef.current) {
      isLoopRunningRef.current = false;
      return;
    }
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const dt = Math.min((now - (lastTimeRef.current || now)) / 1000, 0.05);
    lastTimeRef.current = now;

    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const remaining: Particle2D[] = [];
      for (const p of particlesRef.current) {
        p.life += dt;
        if (p.life < p.maxLife) {
          // Glass shard physics: drag and subtle gravity drift
          p.vx *= Math.pow(0.94, dt * 60);
          p.vy = (p.vy + 190 * dt) * Math.pow(0.96, dt * 60);
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.rotation += p.vRot * dt;
          p.vRot *= Math.pow(0.97, dt * 60);

          // Vanishes completely within 2 seconds:
          // Full opacity for first 55%, then smooth fade-out and shrink to 0 by maxLife
          const progress = p.life / p.maxLife;
          const alpha = progress < 0.55 ? 1 : Math.max(0, 1 - (progress - 0.55) / 0.45);
          const scale = progress < 0.55 ? 1 : Math.max(0.08, 1 - (progress - 0.55) * 0.92);

          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.scale(scale, scale);

          // Shard fill
          ctx.fillStyle = p.color;
          ctx.globalAlpha = alpha * 0.95;
          ctx.beginPath();
          ctx.moveTo(p.points[0][0], p.points[0][1]);
          ctx.lineTo(p.points[1][0], p.points[1][1]);
          ctx.lineTo(p.points[2][0], p.points[2][1]);
          ctx.closePath();
          ctx.fill();

          // Glass specular reflection edge
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.8;
          ctx.globalAlpha = alpha * 0.85;
          ctx.stroke();

          ctx.restore();

          remaining.push(p);
        }
      }
      particlesRef.current = remaining;
    }

    if (particlesRef.current.length > 0) {
      animFrameIdRef.current = requestAnimationFrame(renderParticles);
    } else {
      isLoopRunningRef.current = false;
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    }
  }, []);

  // Set up 2D Glass Shatter Particle System on line blast
  useEffect(() => {
    if (!shatteringCells || shatteringCells.length === 0 || !boardRef.current || !canvasRef.current) return;
    const board = boardRef.current;
    const canvas = canvasRef.current;
    const rect = board.getBoundingClientRect();

    if (canvas.width !== rect.width || canvas.height !== rect.height) {
      canvas.width = rect.width;
      canvas.height = rect.height;
    }

    const cellW = rect.width / GRID_SIZE;
    const cellH = rect.height / GRID_SIZE;
    const newParticles: Particle2D[] = [];

    shatteringCells.forEach(cell => {
      const centerX = (cell.col + 0.5) * cellW;
      const centerY = (cell.row + 0.5) * cellH;

      // 14 sharp glass shards per cleared cell
      const shardsPerCell = 14;
      for (let i = 0; i < shardsPerCell; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 160 + Math.random() * 340; // Initial burst
        const vx = Math.cos(angle) * speed;
        const vy = Math.sin(angle) * speed - 60; // slight upward pop
        const size = cellW * (0.22 + Math.random() * 0.32);

        // Sharp glass fragment polygon
        const p1: [number, number] = [-size / 2, -size / 2];
        const p2: [number, number] = [size / 2, -size / 3];
        const p3: [number, number] = [0, size / 2];

        newParticles.push({
          x: centerX + (Math.random() - 0.5) * cellW * 0.6,
          y: centerY + (Math.random() - 0.5) * cellH * 0.6,
          vx,
          vy,
          size,
          rotation: Math.random() * Math.PI * 2,
          vRot: (Math.random() - 0.5) * 14,
          color: cell.color,
          points: [p1, p2, p3],
          life: 0,
          // Guaranteed to vanish strictly within 2 seconds (1.50s to 1.92s)
          maxLife: 1.5 + Math.random() * 0.42,
        });
      }
    });

    particlesRef.current.push(...newParticles);

    if (!isLoopRunningRef.current) {
      isLoopRunningRef.current = true;
      lastTimeRef.current = performance.now();
      animFrameIdRef.current = requestAnimationFrame(renderParticles);
    }
  }, [shatteringCells, boardRef, renderParticles]);

  // Clean unmount cancel
  useEffect(() => {
    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, []);

  // Fast lookup set for ghost preview cells
  const ghostCellsMap = new Map<string, { isValid: boolean }>();
  if (hoveredPlacement) {
    const { piece, row, col, isValid } = hoveredPlacement;
    for (let r = 0; r < piece.height; r++) {
      for (let c = 0; c < piece.width; c++) {
        if (piece.matrix[r][c] === 1) {
          const targetRow = row + r;
          const targetCol = col + c;
          if (targetRow >= 0 && targetRow < GRID_SIZE && targetCol >= 0 && targetCol < GRID_SIZE) {
            ghostCellsMap.set(`${targetRow},${targetCol}`, { isValid });
          }
        }
      }
    }
  }

  // Fast lookup set for hint cells
  const hintCellsSet = new Set<string>();
  if (hintCells) {
    hintCells.forEach(([r, c]) => hintCellsSet.add(`${r},${c}`));
  }

  return (
    <div className="w-full flex items-center justify-center p-2 sm:p-4 select-none touch-none">
      {/* 
        Solid, Color-Changing Boundary Frame:
        Changes color smoothly on every 5,000-point milestone!
      */}
      <div
        className="relative p-2.5 sm:p-3.5 rounded-2xl sm:rounded-3xl transition-all duration-700 ease-out shadow-2xl border-[6px] sm:border-[8px]"
        style={{
          borderColor: theme.solidBoundaryColor,
          backgroundColor: '#070b14',
          boxShadow: `
            0 0 30px ${theme.solidBoundaryColor}45,
            inset 0 0 12px ${theme.solidBoundaryColor}20
          `,
        }}
      >
        {/* Grid Container */}
        <div
          ref={boardRef}
          className="relative grid grid-cols-10 grid-rows-10 gap-1 sm:gap-1.5 w-[min(88vw,420px)] aspect-square bg-slate-950/95 rounded-xl sm:rounded-2xl p-1.5 sm:p-2 border border-slate-800/80 shadow-inner"
        >
          {Array.from({ length: GRID_SIZE }).map((_, r) =>
            Array.from({ length: GRID_SIZE }).map((_, c) => {
              const cellColor = grid[r][c];
              const cellKey = `${r},${c}`;
              const ghost = ghostCellsMap.get(cellKey);
              const isHint = hintCellsSet.has(cellKey);
              const isNewlyPlaced = placedAnimationCells?.has(cellKey);

              return (
                <div
                  key={cellKey}
                  data-row={r}
                  data-col={c}
                  onClick={() => onCellClick?.(r, c)}
                  className={`relative rounded-[5px] sm:rounded-[7px] transition-all duration-150 flex items-center justify-center cursor-pointer border ${
                    cellColor
                      ? 'shadow-md border-transparent'
                      : 'hover:brightness-125'
                  } ${isHint && !cellColor ? 'ring-2 ring-amber-400 bg-amber-400/25 animate-pulse' : ''} ${
                    isNewlyPlaced ? 'animate-block-drop z-10' : ''
                  }`}
                  style={{
                    backgroundColor: cellColor ? cellColor : 'rgba(10, 16, 30, 0.75)',
                    borderColor: cellColor ? 'transparent' : `${theme.solidBoundaryColor}40`,
                    boxShadow: cellColor
                      ? `
                        inset 0 2px 2px 0 rgba(255, 255, 255, 0.45),
                        inset 0 -2px 3px 0 rgba(0, 0, 0, 0.4),
                        0 2px 4px rgba(0, 0, 0, 0.5),
                        0 0 10px ${cellColor}40
                      `
                      : `
                        0 0 7px ${theme.solidBoundaryColor}26,
                        inset 0 0 5px ${theme.solidBoundaryColor}16,
                        0 1px 2px rgba(0, 0, 0, 0.5)
                      `,
                  }}
                >
                  {/* Placed Block 2D Gloss Bevel */}
                  {cellColor && (
                    <div className="absolute top-0.5 left-0.5 right-0.5 h-1 sm:h-1.5 rounded-t-[3px] bg-white/30 pointer-events-none" />
                  )}

                  {/* Empty cell slightly glowing inner highlight & micro dot */}
                  {!cellColor && !ghost && (
                    <>
                      <div className="absolute top-0.5 left-0.5 right-0.5 h-[2px] rounded-t-[2px] bg-white/10 pointer-events-none" />
                      <div
                        className="w-1.5 h-1.5 rounded-full pointer-events-none transition-colors duration-700"
                        style={{
                          backgroundColor: `${theme.solidBoundaryColor}50`,
                          boxShadow: `0 0 4px ${theme.solidBoundaryColor}80`,
                        }}
                      />
                    </>
                  )}

                  {/* Ghost Placement Preview */}
                  {ghost && (
                    <div
                      className={`absolute inset-0 rounded-[5px] sm:rounded-[7px] border-2 transition-all duration-100 ${
                        ghost.isValid
                          ? 'bg-emerald-400/55 border-emerald-300 shadow-md shadow-emerald-500/40 ring-1 ring-emerald-400/50'
                          : 'bg-rose-500/50 border-rose-400 shadow-md shadow-rose-500/40 ring-1 ring-rose-400/40'
                      }`}
                    >
                      <div className="absolute top-0.5 left-0.5 right-0.5 h-1 rounded-t-[3px] bg-white/40" />
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* 2D Glass Shatter Particle Canvas Overlay */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 pointer-events-none z-30"
          />

          {/* Huge Gained Score Popup */}
          {scoreBurst && (
            <div
              key={scoreBurst.id}
              className="absolute inset-0 pointer-events-none z-40 flex flex-col items-center justify-center animate-score-pop select-none"
            >
              <div
                className={`font-black font-game tracking-tight drop-shadow-2xl ${
                  scoreBurst.isBig
                    ? 'text-6xl sm:text-8xl text-yellow-300 drop-shadow-[0_0_40px_rgba(253,224,71,0.95)] scale-110'
                    : 'text-4xl sm:text-5xl text-cyan-300 drop-shadow-[0_0_20px_rgba(34,211,238,0.85)]'
                }`}
                style={{
                  WebkitTextStroke: scoreBurst.isBig ? '3.5px #020617' : '2px #020617',
                  textShadow: '0 4px 20px rgba(0, 0, 0, 0.9), 0 0 45px currentColor',
                }}
              >
                +{scoreBurst.points}
              </div>
              {scoreBurst.label && (
                <div
                  className={`mt-1.5 px-4 py-1 rounded-full font-black font-game text-xs sm:text-sm tracking-widest uppercase shadow-2xl ${
                    scoreBurst.label.includes('JACKPOT')
                      ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 text-slate-950 border-2 border-white shadow-yellow-400/80 animate-pulse scale-105'
                      : scoreBurst.label.includes('UNBELIEVABLE')
                      ? 'bg-slate-950/95 border-2 border-rose-400 text-rose-300 shadow-rose-500/60'
                      : 'bg-slate-950/95 border-2 border-amber-400 text-amber-300 shadow-amber-500/50'
                  }`}
                >
                  {scoreBurst.label}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
