import React from 'react';
import { Piece } from '../types/game';

interface TrayPiecesProps {
  pieces: (Piece | null)[];
  selectedPieceIndex: number | null;
  draggedPieceIndex?: number | null;
  onDragStart: (index: number, clientX: number, clientY: number) => void;
  onPieceSelect?: (index: number) => void;
  disabled?: boolean;
}

export const TrayPieces: React.FC<TrayPiecesProps> = ({
  pieces,
  selectedPieceIndex,
  draggedPieceIndex = null,
  onDragStart,
  onPieceSelect,
  disabled = false,
}) => {
  return (
    <div className="w-full max-w-lg mx-auto px-4 py-2 flex items-center justify-around gap-2.5 select-none touch-none">
      {pieces.map((piece, index) => {
        if (!piece) {
          return (
            <div
              key={`empty-${index}`}
              className="flex-1 h-24 sm:h-28 rounded-2xl bg-slate-900/40 border border-slate-800/40 flex items-center justify-center opacity-30 transition-all duration-300"
            >
              <div className="w-8 h-8 rounded-full border border-dashed border-slate-700/50" />
            </div>
          );
        }

        const isSelected = selectedPieceIndex === index;
        const isDragging = draggedPieceIndex === index;

        return (
          <div
            key={piece.id}
            onPointerDown={(e) => {
              if (disabled) return;
              e.preventDefault();
              onDragStart(index, e.clientX, e.clientY);
            }}
            onClick={() => {
              if (disabled) return;
              onPieceSelect?.(index);
            }}
            className={`flex-1 h-24 sm:h-28 rounded-2xl border transition-all duration-200 cursor-grab active:cursor-grabbing flex items-center justify-center p-2 group relative overflow-hidden select-none ${
              isDragging
                ? 'opacity-35 scale-90 border-cyan-400/50 bg-slate-950/70 shadow-inner'
                : isSelected
                ? 'border-yellow-400 ring-2 ring-yellow-400/40 shadow-lg shadow-yellow-500/20 scale-105 bg-slate-900/90'
                : 'border-slate-800 hover:border-slate-700 bg-gradient-to-b from-slate-900/90 to-slate-950/90 hover:scale-[1.03] shadow-md'
            }`}
          >
            {/* Subtle background glow */}
            <div
              className={`absolute inset-0 opacity-15 blur-lg pointer-events-none transition-opacity duration-300 ${
                isDragging ? 'opacity-0' : 'group-hover:opacity-35'
              }`}
              style={{ backgroundColor: piece.color }}
            />

            {/* Block Render of the Piece */}
            <div
              className={`grid gap-1 transition-transform duration-200 pointer-events-none ${
                isDragging ? 'scale-90 opacity-60' : 'group-hover:scale-105'
              }`}
              style={{
                gridTemplateRows: `repeat(${piece.height}, minmax(0, 1fr))`,
                gridTemplateColumns: `repeat(${piece.width}, minmax(0, 1fr))`,
              }}
            >
              {piece.matrix.map((rowArr, r) =>
                rowArr.map((filled, c) => {
                  if (filled === 0) {
                    return <div key={`${r}-${c}`} className="w-5 h-5 sm:w-6 sm:h-6" />;
                  }
                  return (
                    <div
                      key={`${r}-${c}`}
                      className="w-5 h-5 sm:w-6 sm:h-6 rounded-[5px] relative transition-transform shadow-md"
                      style={{
                        backgroundColor: piece.color,
                        boxShadow: `
                          0 3px 0 0 #00000088,
                          inset 0 1px 1px 0 rgba(255, 255, 255, 0.6),
                          inset 0 -2px 3px 0 rgba(0, 0, 0, 0.4),
                          0 0 8px ${piece.color}66
                        `,
                      }}
                    >
                      {/* Top specular shine highlight */}
                      <div className="absolute top-0.5 left-0.5 right-0.5 h-1.5 rounded-t-[3px] bg-white/40 pointer-events-none" />
                    </div>
                  );
                })
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
