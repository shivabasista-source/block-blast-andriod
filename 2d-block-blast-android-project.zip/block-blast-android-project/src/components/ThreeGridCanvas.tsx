import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Grid, Piece, ThemeConfig } from '../types/game';
import { GRID_SIZE } from '../utils/gameLogic';

interface ThreeGridCanvasProps {
  grid: Grid;
  theme: ThemeConfig;
  hoveredPlacement: {
    piece: Piece;
    row: number;
    col: number;
    isValid: boolean;
  } | null;
  hintCells: [number, number][] | null;
  shatteringCells: { row: number; col: number; color: string }[] | null;
  onCellClick?: (row: number, col: number) => void;
}

const CELL_SIZE = 1.0;
const HALF_GRID = (GRID_SIZE - 1) / 2; // 4.5
const BOARD_SIZE = GRID_SIZE * CELL_SIZE;

// Helper to convert grid row/col to 3D world position
export function gridToWorld(row: number, col: number): { x: number; z: number } {
  return {
    x: (col - HALF_GRID) * CELL_SIZE,
    z: (row - HALF_GRID) * CELL_SIZE,
  };
}

// Glass shard particle definition
interface GlassShardMesh {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  rx: number;
  ry: number;
  rz: number;
  life: number;
  maxLife: number;
}

export const ThreeGridCanvas: React.FC<ThreeGridCanvasProps> = ({
  grid,
  theme,
  hoveredPlacement,
  hintCells,
  shatteringCells,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animFrameIdRef = useRef<number>(0);

  // Groups and objects
  const boardGroupRef = useRef<THREE.Group | null>(null);
  const placedBlocksGroupRef = useRef<THREE.Group | null>(null);
  const ghostGroupRef = useRef<THREE.Group | null>(null);
  const hintGroupRef = useRef<THREE.Group | null>(null);
  const shardsListRef = useRef<GlassShardMesh[]>([]);

  // Lights for dynamic theme updates
  const keyLightRef = useRef<THREE.DirectionalLight | null>(null);
  const pointLightRef = useRef<THREE.PointLight | null>(null);
  const hemiLightRef = useRef<THREE.HemisphereLight | null>(null);
  const boardGlowMeshRef = useRef<THREE.Mesh | null>(null);

  // Cyber boundary refs
  const conduitMatRef = useRef<THREE.MeshBasicMaterial | null>(null);
  const cornerCoreMatRef = useRef<THREE.MeshBasicMaterial | null>(null);
  const tickMatRef = useRef<THREE.MeshBasicMaterial | null>(null);
  const underglowMeshRef = useRef<THREE.Mesh | null>(null);
  const runnersRef = useRef<THREE.Mesh[]>([]);
  const cornerCoresListRef = useRef<THREE.Mesh[]>([]);

  // Materials cache
  const blockGeoRef = useRef<THREE.BufferGeometry | null>(null);
  const cellBevelGeoRef = useRef<THREE.BufferGeometry | null>(null);

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x020617, 0.025);

    // Camera: high-readability 3D angle (58 deg perspective tilt)
    const camera = new THREE.PerspectiveCamera(46, width / height, 0.1, 100);
    const isMobile = width < 640;
    // Mobile distance compensation
    const cameraY = isMobile ? 14.5 : 12.8;
    const cameraZ = isMobile ? 9.8 : 8.6;
    camera.position.set(0, cameraY, cameraZ);
    camera.lookAt(0, -0.4, 0.5);
    cameraRef.current = camera;

    // WebGL Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Reusable Geometries
    // Rounded beveled block: Extrude beveled rounded rectangle
    const createRoundedCubeGeo = (size: number, bevel: number) => {
      const shape = new THREE.Shape();
      const half = size / 2;
      const r = bevel * 0.9;
      shape.moveTo(-half + r, -half);
      shape.lineTo(half - r, -half);
      shape.quadraticCurveTo(half, -half, half, -half + r);
      shape.lineTo(half, half - r);
      shape.quadraticCurveTo(half, half, half - r, half);
      shape.lineTo(-half + r, half);
      shape.quadraticCurveTo(-half, half, -half, half - r);
      shape.lineTo(-half, -half + r);
      shape.quadraticCurveTo(-half, -half, -half + r, -half);

      const extrudeSettings: THREE.ExtrudeGeometryOptions = {
        depth: size * 0.72,
        bevelEnabled: true,
        bevelSegments: 2,
        steps: 1,
        bevelSize: bevel,
        bevelThickness: bevel,
      };
      const geo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      geo.center();
      geo.rotateX(-Math.PI / 2); // face upwards
      return geo;
    };

    blockGeoRef.current = createRoundedCubeGeo(0.86, 0.04);
    cellBevelGeoRef.current = createRoundedCubeGeo(0.92, 0.02);

    // Studio Lighting
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x020617, 0.85);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);
    hemiLightRef.current = hemiLight;

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.6);
    keyLight.position.set(6, 16, 8);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 30;
      const d = 8;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);
    keyLightRef.current = keyLight;

    // Glowing Point light centered above board
    const pointLight = new THREE.PointLight(theme.boardGlowColor, 2.5, 18, 1.2);
    pointLight.position.set(0, 3.5, 0);
    scene.add(pointLight);
    pointLightRef.current = pointLight;

    // 1. Build High-Tech AI Game 10x10 Board & Beautiful Cyber Boundary
    const boardGroup = new THREE.Group();
    scene.add(boardGroup);
    boardGroupRef.current = boardGroup;

    // Helper to create chamfered cyber polygon
    const createChamferedPolygon = (halfSize: number, chamfer: number) => {
      const shape = new THREE.Shape();
      shape.moveTo(-halfSize + chamfer, -halfSize);
      shape.lineTo(halfSize - chamfer, -halfSize);
      shape.lineTo(halfSize, -halfSize + chamfer);
      shape.lineTo(halfSize, halfSize - chamfer);
      shape.lineTo(halfSize - chamfer, halfSize);
      shape.lineTo(-halfSize + chamfer, halfSize);
      shape.lineTo(-halfSize, halfSize - chamfer);
      shape.lineTo(-halfSize, -halfSize + chamfer);
      shape.closePath();
      return shape;
    };

    // Tier 1: Main Obsidian Cyber Chassis Base with Chamfered Corners
    const baseHalf = BOARD_SIZE / 2 + 0.68;
    const baseChamfer = 0.45;
    const baseShape = createChamferedPolygon(baseHalf, baseChamfer);
    const baseGeo = new THREE.ExtrudeGeometry(baseShape, {
      depth: 0.58,
      bevelEnabled: true,
      bevelSegments: 2,
      bevelSize: 0.07,
      bevelThickness: 0.07,
    });
    baseGeo.center();
    baseGeo.rotateX(-Math.PI / 2);

    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x070b14,
      metalness: 0.88,
      roughness: 0.22,
    });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = -0.34;
    baseMesh.receiveShadow = true;
    boardGroup.add(baseMesh);

    // Tier 2: Recessed Tech Border Ridge (Dark Gunmetal Trim)
    const innerRimHalf = BOARD_SIZE / 2 + 0.38;
    const innerRimShape = createChamferedPolygon(innerRimHalf, 0.25);
    const innerRimGeo = new THREE.ExtrudeGeometry(innerRimShape, {
      depth: 0.12,
      bevelEnabled: true,
      bevelSegments: 1,
      bevelSize: 0.04,
      bevelThickness: 0.04,
    });
    innerRimGeo.center();
    innerRimGeo.rotateX(-Math.PI / 2);

    const innerRimMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.92,
      roughness: 0.18,
    });
    const innerRimMesh = new THREE.Mesh(innerRimGeo, innerRimMat);
    innerRimMesh.position.y = -0.06;
    boardGroup.add(innerRimMesh);

    // Tier 3: Glowing Neon Energy Conduit Channels (Outer & Inner)
    const conduitMat = new THREE.MeshBasicMaterial({
      color: theme.boardGlowColor,
      transparent: true,
      opacity: 0.9,
    });
    conduitMatRef.current = conduitMat;
    boardGlowMeshRef.current = new THREE.Mesh(new THREE.BufferGeometry(), conduitMat);

    // Outer Neon Border (4 perimeter laser bars)
    const outerBarLength = BOARD_SIZE + 0.5;
    const outerBarThick = 0.04;
    const outerBarHeight = 0.05;
    const outerOffset = BOARD_SIZE / 2 + 0.28;

    const createNeonBar = (w: number, h: number, d: number, x: number, y: number, z: number) => {
      const geo = new THREE.BoxGeometry(w, h, d);
      const mesh = new THREE.Mesh(geo, conduitMat);
      mesh.position.set(x, y, z);
      boardGroup.add(mesh);
      return mesh;
    };

    // 4 Outer neon conduits
    createNeonBar(outerBarLength, outerBarHeight, outerBarThick, 0, 0.01, -outerOffset);
    createNeonBar(outerBarLength, outerBarHeight, outerBarThick, 0, 0.01, outerOffset);
    createNeonBar(outerBarThick, outerBarHeight, outerBarLength, -outerOffset, 0.01, 0);
    createNeonBar(outerBarThick, outerBarHeight, outerBarLength, outerOffset, 0.01, 0);

    // Inner Glowing Matrix Frame (runs right along the 10x10 edge)
    const innerBarLength = BOARD_SIZE + 0.04;
    const innerOffset = BOARD_SIZE / 2 + 0.02;
    createNeonBar(innerBarLength, 0.03, 0.02, 0, 0.015, -innerOffset);
    createNeonBar(innerBarLength, 0.03, 0.02, 0, 0.015, innerOffset);
    createNeonBar(0.02, 0.03, innerBarLength, -innerOffset, 0.015, 0);
    createNeonBar(0.02, 0.03, innerBarLength, innerOffset, 0.015, 0);

    // Tier 4: Four Futuristic Cyber Corner Brackets & Reactor Core Nodes
    const cornerMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.95,
      roughness: 0.15,
    });
    const cornerCoreMat = new THREE.MeshBasicMaterial({
      color: theme.boardGlowColor,
    });
    cornerCoreMatRef.current = cornerCoreMat;

    const cornerCoords = [
      { x: -outerOffset - 0.08, z: -outerOffset - 0.08, rot: 0 },
      { x: outerOffset + 0.08, z: -outerOffset - 0.08, rot: Math.PI / 2 },
      { x: outerOffset + 0.08, z: outerOffset + 0.08, rot: Math.PI },
      { x: -outerOffset - 0.08, z: outerOffset + 0.08, rot: -Math.PI / 2 },
    ];

    const cornerCoresList: THREE.Mesh[] = [];

    cornerCoords.forEach((coord) => {
      const cornerBracket = new THREE.Group();
      cornerBracket.position.set(coord.x, 0.02, coord.z);
      cornerBracket.rotation.y = coord.rot;

      // Heavy angled L-bracket
      const bracketGeo = new THREE.BoxGeometry(0.36, 0.08, 0.36);
      const bracketMesh = new THREE.Mesh(bracketGeo, cornerMat);
      cornerBracket.add(bracketMesh);

      // Glowing Hex/Cylinder Reactor Core Node
      const coreGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.11, 6);
      const coreMesh = new THREE.Mesh(coreGeo, cornerCoreMat);
      coreMesh.position.y = 0.04;
      cornerBracket.add(coreMesh);
      cornerCoresList.push(coreMesh);

      boardGroup.add(cornerBracket);
    });
    cornerCoresListRef.current = cornerCoresList;

    // Tier 5: Coordinate Ticks & Perimeter Laser Hash-Marks
    const tickGeo = new THREE.BoxGeometry(0.06, 0.02, 0.02);
    const tickMat = new THREE.MeshBasicMaterial({
      color: theme.boardGlowColor,
      transparent: true,
      opacity: 0.75,
    });
    tickMatRef.current = tickMat;

    for (let i = 0; i < GRID_SIZE; i++) {
      const pos = (i - HALF_GRID) * CELL_SIZE;

      // Top and bottom ticks
      const tickTop = new THREE.Mesh(tickGeo, tickMat);
      tickTop.position.set(pos, 0.015, -outerOffset - 0.09);
      boardGroup.add(tickTop);

      const tickBottom = new THREE.Mesh(tickGeo, tickMat);
      tickBottom.position.set(pos, 0.015, outerOffset + 0.09);
      boardGroup.add(tickBottom);

      // Left and right ticks (rotated)
      const tickLeft = new THREE.Mesh(tickGeo, tickMat);
      tickLeft.rotation.y = Math.PI / 2;
      tickLeft.position.set(-outerOffset - 0.09, 0.015, pos);
      boardGroup.add(tickLeft);

      const tickRight = new THREE.Mesh(tickGeo, tickMat);
      tickRight.rotation.y = Math.PI / 2;
      tickRight.position.set(outerOffset + 0.09, 0.015, pos);
      boardGroup.add(tickRight);
    }

    // Tier 6: Animated Energy Photon Runners traveling along the boundary
    const runnerGeo = new THREE.SphereGeometry(0.08, 12, 12);
    const runnerMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });
    const runners: THREE.Mesh[] = [];
    for (let i = 0; i < 4; i++) {
      const runner = new THREE.Mesh(runnerGeo, runnerMat);
      runner.position.set(0, 0.05, 0);
      boardGroup.add(runner);
      runners.push(runner);
    }
    runnersRef.current = runners;

    // Tier 7: Lush Volumetric Cyber Underglow Floor Halo
    const underglowCanvas = document.createElement('canvas');
    underglowCanvas.width = 256;
    underglowCanvas.height = 256;
    const uCtx = underglowCanvas.getContext('2d')!;
    const uGrad = uCtx.createRadialGradient(128, 128, 20, 128, 128, 128);
    uGrad.addColorStop(0, theme.boardGlowColor);
    uGrad.addColorStop(0.4, theme.boardGlowColor + '88');
    uGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    uCtx.fillStyle = uGrad;
    uCtx.fillRect(0, 0, 256, 256);

    const underglowTexture = new THREE.CanvasTexture(underglowCanvas);
    const underglowGeo = new THREE.PlaneGeometry(BOARD_SIZE + 4.5, BOARD_SIZE + 4.5);
    const underglowMat = new THREE.MeshBasicMaterial({
      map: underglowTexture,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    const underglowMesh = new THREE.Mesh(underglowGeo, underglowMat);
    underglowMesh.rotateX(-Math.PI / 2);
    underglowMesh.position.y = -0.64;
    boardGroup.add(underglowMesh);
    underglowMeshRef.current = underglowMesh;

    // 100 Individual Cells Pockets with Micro Cyber Crosshairs
    const cellMat = new THREE.MeshStandardMaterial({
      color: 0x0d1322,
      roughness: 0.38,
      metalness: 0.5,
    });
    const cellBorderMat = new THREE.MeshBasicMaterial({
      color: 0x1e293b,
      transparent: true,
      opacity: 0.6,
    });
    const cellDotMat = new THREE.MeshBasicMaterial({
      color: 0x334155,
      transparent: true,
      opacity: 0.7,
    });

    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        const { x, z } = gridToWorld(r, c);

        // Cell pocket floor
        const cellFloorMesh = new THREE.Mesh(cellBevelGeoRef.current!, cellMat);
        cellFloorMesh.position.set(x, -0.05, z);
        cellFloorMesh.receiveShadow = true;
        boardGroup.add(cellFloorMesh);

        // Thin recessed cell border lines
        const borderGeo = new THREE.BoxGeometry(0.96, 0.02, 0.96);
        const borderMesh = new THREE.Mesh(borderGeo, cellBorderMat);
        borderMesh.position.set(x, 0.005, z);
        boardGroup.add(borderMesh);

        // Subtle tech dot in center of empty cell pocket
        const dotGeo = new THREE.BoxGeometry(0.06, 0.008, 0.06);
        const dotMesh = new THREE.Mesh(dotGeo, cellDotMat);
        dotMesh.position.set(x, 0.01, z);
        boardGroup.add(dotMesh);
      }
    }

    // Dynamic Placed Blocks Group
    const placedBlocksGroup = new THREE.Group();
    scene.add(placedBlocksGroup);
    placedBlocksGroupRef.current = placedBlocksGroup;

    // Ghost Preview Group
    const ghostGroup = new THREE.Group();
    scene.add(ghostGroup);
    ghostGroupRef.current = ghostGroup;

    // Hint Group
    const hintGroup = new THREE.Group();
    scene.add(hintGroup);
    hintGroupRef.current = hintGroup;

    // Resize Handler
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const newWidth = containerRef.current.clientWidth;
      const newHeight = containerRef.current.clientHeight;
      const cam = cameraRef.current;
      cam.aspect = newWidth / newHeight;

      const mobile = newWidth < 640;
      cam.position.set(0, mobile ? 14.5 : 12.8, mobile ? 9.8 : 8.6);
      cam.updateProjectionMatrix();

      rendererRef.current.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let lastTime = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      // Update glass shards
      if (shardsListRef.current.length > 0) {
        const remainingShards: GlassShardMesh[] = [];

        for (const shard of shardsListRef.current) {
          shard.life += dt;
          if (shard.life < shard.maxLife) {
            // Apply physics: gravity + velocity
            shard.vy -= 9.8 * dt;
            shard.mesh.position.x += shard.vx * dt;
            shard.mesh.position.y += shard.vy * dt;
            shard.mesh.position.z += shard.vz * dt;

            // Rotation
            shard.mesh.rotation.x += shard.rx * dt;
            shard.mesh.rotation.y += shard.ry * dt;
            shard.mesh.rotation.z += shard.rz * dt;

            // Scale down & fade out
            const progress = shard.life / shard.maxLife;
            const s = Math.max(0.001, 1 - progress);
            shard.mesh.scale.set(s, s, s);

            const mat = shard.mesh.material as THREE.MeshStandardMaterial;
            if (mat.opacity !== undefined) {
              mat.opacity = (1 - progress) * 0.95;
            }

            remainingShards.push(shard);
          } else {
            // Dispose shard
            scene.remove(shard.mesh);
            shard.mesh.geometry.dispose();
            if (Array.isArray(shard.mesh.material)) {
              shard.mesh.material.forEach(m => m.dispose());
            } else {
              shard.mesh.material.dispose();
            }
          }
        }

        shardsListRef.current = remainingShards;
      }

      // Animate boundary energy runners along perimeter channels
      if (runnersRef.current && runnersRef.current.length === 4) {
        const outerOffset = BOARD_SIZE / 2 + 0.28;
        const span = outerOffset * 2;
        const progress = (now * 0.00032) % 1;

        // Runner 0: moves right along top edge (-z)
        runnersRef.current[0].position.set(-outerOffset + progress * span, 0.04, -outerOffset);
        // Runner 1: moves down along right edge (+x)
        const p1 = (progress + 0.25) % 1;
        runnersRef.current[1].position.set(outerOffset, 0.04, -outerOffset + p1 * span);
        // Runner 2: moves left along bottom edge (+z)
        const p2 = (progress + 0.5) % 1;
        runnersRef.current[2].position.set(outerOffset - p2 * span, 0.04, outerOffset);
        // Runner 3: moves up along left edge (-x)
        const p3 = (progress + 0.75) % 1;
        runnersRef.current[3].position.set(-outerOffset, 0.04, outerOffset - p3 * span);
      }

      // Animate corner reactor cores breathing pulse
      if (cornerCoresListRef.current.length > 0) {
        cornerCoresListRef.current.forEach((core, idx) => {
          const s = 1 + Math.sin(now * 0.006 + idx * 1.5) * 0.2;
          core.scale.set(s, 1, s);
        });
      }

      // Animate neon conduit emission pulse
      if (conduitMatRef.current) {
        conduitMatRef.current.opacity = 0.8 + Math.sin(now * 0.004) * 0.18;
      }

      // Animate hint pulsing
      if (hintGroupRef.current && hintGroupRef.current.children.length > 0) {
        const pulse = Math.sin(now * 0.008) * 0.15 + 0.85;
        hintGroupRef.current.children.forEach(child => {
          child.scale.set(pulse, pulse, pulse);
        });
      }

      // Animate subtle glow on board lights
      if (pointLightRef.current) {
        pointLightRef.current.intensity = 2.4 + Math.sin(now * 0.003) * 0.4;
      }

      renderer.render(scene, camera);
      animFrameIdRef.current = requestAnimationFrame(tick);
    };

    animFrameIdRef.current = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(animFrameIdRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update theme colors
  useEffect(() => {
    if (pointLightRef.current) {
      pointLightRef.current.color.set(theme.boardGlowColor);
    }
    if (keyLightRef.current) {
      keyLightRef.current.color.set(theme.keyLightColor);
    }
    if (boardGlowMeshRef.current) {
      const mat = boardGlowMeshRef.current.material as THREE.MeshBasicMaterial;
      mat.color.set(theme.boardGlowColor);
    }
    if (conduitMatRef.current) {
      conduitMatRef.current.color.set(theme.boardGlowColor);
    }
    if (cornerCoreMatRef.current) {
      cornerCoreMatRef.current.color.set(theme.boardGlowColor);
    }
    if (tickMatRef.current) {
      tickMatRef.current.color.set(theme.boardGlowColor);
    }
    if (underglowMeshRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const grad = ctx.createRadialGradient(128, 128, 20, 128, 128, 128);
        grad.addColorStop(0, theme.boardGlowColor);
        grad.addColorStop(0.4, theme.boardGlowColor + '88');
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 256, 256);
        const tex = new THREE.CanvasTexture(canvas);
        const mat = underglowMeshRef.current.material as THREE.MeshBasicMaterial;
        mat.map?.dispose();
        mat.map = tex;
        mat.needsUpdate = true;
      }
    }
  }, [theme]);

  // Update Placed Blocks
  useEffect(() => {
    if (!placedBlocksGroupRef.current || !blockGeoRef.current) return;
    const group = placedBlocksGroupRef.current;

    // Clear previous blocks
    while (group.children.length > 0) {
      const child = group.children[0] as THREE.Mesh;
      group.remove(child);
      if (child.material) {
        if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
        else child.material.dispose();
      }
    }

    // Material cache per color
    const matCache = new Map<string, THREE.MeshStandardMaterial>();

    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        const color = grid[r][c];
        if (color) {
          let mat = matCache.get(color);
          if (!mat) {
            mat = new THREE.MeshStandardMaterial({
              color: new THREE.Color(color),
              roughness: 0.18,
              metalness: 0.22,
              emissive: new THREE.Color(color),
              emissiveIntensity: 0.28,
            });
            matCache.set(color, mat);
          }

          const mesh = new THREE.Mesh(blockGeoRef.current, mat);
          const { x, z } = gridToWorld(r, c);
          mesh.position.set(x, 0.32, z);
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          group.add(mesh);
        }
      }
    }
  }, [grid]);

  // Handle Glass Shatter Animation when lines clear
  useEffect(() => {
    if (!shatteringCells || shatteringCells.length === 0 || !sceneRef.current) return;

    // Spawn 3D glass shards for each cleared block
    const scene = sceneRef.current;
    const newShards: GlassShardMesh[] = [];

    shatteringCells.forEach(cell => {
      const { x, z } = gridToWorld(cell.row, cell.col);
      const shardCount = 8; // 8 shards per block for dramatic explosive effect

      for (let i = 0; i < shardCount; i++) {
        // Create sharp triangular glass shard geometry
        const size = 0.12 + Math.random() * 0.14;
        const geom = new THREE.ConeGeometry(size, size * 1.8, 3);

        const shardMat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(cell.color),
          emissive: new THREE.Color(cell.color),
          emissiveIntensity: 0.6,
          roughness: 0.1,
          metalness: 0.8,
          transparent: true,
          opacity: 0.95,
        });

        const mesh = new THREE.Mesh(geom, shardMat);
        mesh.position.set(
          x + (Math.random() - 0.5) * 0.5,
          0.35 + (Math.random() - 0.5) * 0.3,
          z + (Math.random() - 0.5) * 0.5
        );

        // Explosive radial velocity (burst outwards in all directions)
        const angle = Math.random() * Math.PI * 2;
        const speed = 2.5 + Math.random() * 4.5;
        const vx = Math.cos(angle) * speed;
        const vy = 3.0 + Math.random() * 5.0; // strong upward pop
        const vz = Math.sin(angle) * speed;

        mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
        scene.add(mesh);

        newShards.push({
          mesh,
          vx,
          vy,
          vz,
          rx: (Math.random() - 0.5) * 18,
          ry: (Math.random() - 0.5) * 18,
          rz: (Math.random() - 0.5) * 18,
          life: 0,
          maxLife: 0.28 + Math.random() * 0.12, // 0.28-0.40 seconds exactly as required!
        });
      }
    });

    shardsListRef.current.push(...newShards);
  }, [shatteringCells]);

  // Update Ghost Placement Preview
  useEffect(() => {
    if (!ghostGroupRef.current || !blockGeoRef.current) return;
    const group = ghostGroupRef.current;

    // Clear existing ghost blocks
    while (group.children.length > 0) {
      const child = group.children[0] as THREE.Mesh;
      group.remove(child);
      if (child.material) {
        if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
        else child.material.dispose();
      }
    }

    if (!hoveredPlacement) return;

    const { piece, row, col, isValid } = hoveredPlacement;
    const ghostColor = isValid ? new THREE.Color(0x22c55e) : new THREE.Color(0xef4444);

    const ghostMat = new THREE.MeshStandardMaterial({
      color: ghostColor,
      emissive: ghostColor,
      emissiveIntensity: isValid ? 0.75 : 0.45,
      transparent: true,
      opacity: isValid ? 0.65 : 0.45,
      roughness: 0.2,
      metalness: 0.3,
    });

    for (let r = 0; r < piece.height; r++) {
      for (let c = 0; c < piece.width; c++) {
        if (piece.matrix[r][c] === 1) {
          const targetRow = row + r;
          const targetCol = col + c;

          // Only render preview inside grid
          if (targetRow >= 0 && targetRow < GRID_SIZE && targetCol >= 0 && targetCol < GRID_SIZE) {
            const mesh = new THREE.Mesh(blockGeoRef.current, ghostMat);
            const { x, z } = gridToWorld(targetRow, targetCol);
            mesh.position.set(x, 0.4, z); // slight hover elevation
            group.add(mesh);
          }
        }
      }
    }
  }, [hoveredPlacement]);

  // Update Hint Highlights
  useEffect(() => {
    if (!hintGroupRef.current) return;
    const group = hintGroupRef.current;

    while (group.children.length > 0) {
      const child = group.children[0] as THREE.Mesh;
      group.remove(child);
      if (child.material) {
        if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
        else child.material.dispose();
      }
    }

    if (!hintCells || hintCells.length === 0) return;

    const goldColor = new THREE.Color(0xfacc15);
    const hintGeo = new THREE.BoxGeometry(0.94, 0.08, 0.94);
    const hintMat = new THREE.MeshBasicMaterial({
      color: goldColor,
      transparent: true,
      opacity: 0.85,
    });

    hintCells.forEach(([r, c]) => {
      const { x, z } = gridToWorld(r, c);
      const mesh = new THREE.Mesh(hintGeo, hintMat);
      mesh.position.set(x, 0.1, z);
      group.add(mesh);
    });
  }, [hintCells]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative cursor-pointer touch-none select-none"
    >
      {/* Sci-Fi HUD Corner Brackets & Telemetry Framing */}
      <div className="absolute top-2 left-3 flex items-center gap-1.5 pointer-events-none text-[10px] font-mono text-cyan-400/70 tracking-wider">
        <span
          className="w-1.5 h-1.5 rounded-full animate-pulse"
          style={{ backgroundColor: theme.boardGlowColor }}
        />
        <span className="font-semibold uppercase">10×10 MATRIX // AI CHASSIS</span>
      </div>

      <div className="absolute top-2 right-3 pointer-events-none text-[10px] font-mono text-slate-500/80 tracking-wider">
        CORE: 100 CELLS [ONLINE]
      </div>

      {/* Cyber Corner Visual Accents */}
      <div
        className="absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 pointer-events-none transition-colors duration-500"
        style={{ borderColor: theme.accentColor + '99' }}
      />
      <div
        className="absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 pointer-events-none transition-colors duration-500"
        style={{ borderColor: theme.accentColor + '99' }}
      />
      <div
        className="absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 pointer-events-none transition-colors duration-500"
        style={{ borderColor: theme.accentColor + '99' }}
      />
      <div
        className="absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 pointer-events-none transition-colors duration-500"
        style={{ borderColor: theme.accentColor + '99' }}
      />
    </div>
  );
};
