/**
 * High-performance Web Audio API Procedural Sound Engine & Speech Synthesizer
 * Zero external asset dependencies. 100% self-contained & responsive.
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicInterval: number | null = null;
  private isMusicPlaying = false;
  private currentStep = 0;

  // Settings & Volumes (0 to 1)
  public soundEnabled = true;
  public musicEnabled = true;
  public vibrationEnabled = true;
  public voiceEnabled = true;
  public sfxVolume = 0.85;
  public musicVolume = 0.65;
  private cachedVoices: SpeechSynthesisVoice[] = [];

  constructor() {
    // Load persisted preferences
    try {
      this.soundEnabled = localStorage.getItem('blockblast_sfx') !== 'false';
      this.musicEnabled = localStorage.getItem('blockblast_bgm') !== 'false';
      this.vibrationEnabled = localStorage.getItem('blockblast_vib') !== 'false';
      this.voiceEnabled = localStorage.getItem('blockblast_voice') !== 'false';

      const savedSfxVol = localStorage.getItem('blockblast_sfx_vol');
      if (savedSfxVol !== null) this.sfxVolume = parseFloat(savedSfxVol);

      const savedMusicVol = localStorage.getItem('blockblast_music_vol');
      if (savedMusicVol !== null) this.musicVolume = parseFloat(savedMusicVol);
    } catch {
      // LocalStorage fallback
    }

    // Pre-cache speech synthesis voices
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.cachedVoices = window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.cachedVoices = window.speechSynthesis.getVoices();
      };
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.musicGain = this.ctx.createGain();
        this.musicGain.gain.value = this.musicEnabled ? this.musicVolume * 0.4 : 0;
        this.musicGain.connect(this.ctx.destination);

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.value = this.soundEnabled ? this.sfxVolume * 0.7 : 0;
        this.sfxGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setSfxVolume(vol: number) {
    this.sfxVolume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('blockblast_sfx_vol', String(this.sfxVolume));
    } catch {}
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(this.soundEnabled ? this.sfxVolume * 0.7 : 0, this.ctx.currentTime);
    }
  }

  public setMusicVolume(vol: number) {
    this.musicVolume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('blockblast_music_vol', String(this.musicVolume));
    } catch {}
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(this.musicEnabled ? this.musicVolume * 0.4 : 0, this.ctx.currentTime);
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    try {
      localStorage.setItem('blockblast_sfx', String(enabled));
    } catch {}
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(enabled ? this.sfxVolume * 0.7 : 0, this.ctx.currentTime);
    }
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    try {
      localStorage.setItem('blockblast_bgm', String(enabled));
    } catch {}
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(enabled ? this.musicVolume * 0.4 : 0, this.ctx.currentTime);
    }
    if (enabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  public setVibrationEnabled(enabled: boolean) {
    this.vibrationEnabled = enabled;
    try {
      localStorage.setItem('blockblast_vib', String(enabled));
    } catch {}
  }

  public setVoiceEnabled(enabled: boolean) {
    this.voiceEnabled = enabled;
    try {
      localStorage.setItem('blockblast_voice', String(enabled));
    } catch {}
  }

  // --- Sound Effects ---

  /**
   * Smooth, magnetic block pickup sound
   */
  public playPickup() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    
    // Smooth frequency glide with gentle warmth
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, t);
    osc.frequency.exponentialRampToValueAtTime(540, t + 0.09);

    gain.gain.setValueAtTime(0.42, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.1);

    // Subtle tactile tick on pickup
    this.vibrate(8);
  }

  /**
   * LOUDER, crisp & tactile block moving/hovering sound
   * Dual-layered: punchy transient click + acoustic resonant body
   */
  public playHoverSnap(isValid = true) {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;

    // Layer 1: Crisp click transient (cuts through clearly and audibly)
    const clickOsc = this.ctx.createOscillator();
    const clickGain = this.ctx.createGain();

    clickOsc.type = 'triangle';
    const startFreq = isValid ? 1200 : 750;
    const endFreq = isValid ? 680 : 380;
    clickOsc.frequency.setValueAtTime(startFreq, t);
    clickOsc.frequency.exponentialRampToValueAtTime(endFreq, t + 0.038);

    // High audible gain (much louder than previous 0.08)
    clickGain.gain.setValueAtTime(0.42, t);
    clickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.038);

    clickOsc.connect(clickGain);
    clickGain.connect(this.sfxGain);
    clickOsc.start(t);
    clickOsc.stop(t + 0.038);

    // Layer 2: Warm tactile wooden resonance pop
    const bodyOsc = this.ctx.createOscillator();
    const bodyGain = this.ctx.createGain();
    const bodyFilter = this.ctx.createBiquadFilter();

    bodyOsc.type = 'sine';
    bodyOsc.frequency.setValueAtTime(isValid ? 540 : 360, t);
    bodyOsc.frequency.exponentialRampToValueAtTime(isValid ? 320 : 220, t + 0.045);

    bodyFilter.type = 'bandpass';
    bodyFilter.frequency.setValueAtTime(isValid ? 600 : 380, t);
    bodyFilter.Q.setValueAtTime(2.5, t);

    bodyGain.gain.setValueAtTime(0.35, t);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, t + 0.048);

    bodyOsc.connect(bodyFilter);
    bodyFilter.connect(bodyGain);
    bodyGain.connect(this.sfxGain);

    bodyOsc.start(t);
    bodyOsc.stop(t + 0.048);

    this.vibrate(isValid ? 8 : 4);
  }

  /**
   * Deep, punchy, smooth placement thud with acoustic block drop resonance
   */
  public playPlacement() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;

    // Sub bass drop impact
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(160, t);
    osc1.frequency.exponentialRampToValueAtTime(42, t + 0.14);

    gain1.gain.setValueAtTime(0.65, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

    osc1.connect(gain1);
    gain1.connect(this.sfxGain);
    osc1.start(t);
    osc1.stop(t + 0.14);

    // Tactile acoustic block latch
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(780, t);
    osc2.frequency.exponentialRampToValueAtTime(320, t + 0.08);

    gain2.gain.setValueAtTime(0.38, t);
    gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

    osc2.connect(gain2);
    gain2.connect(this.sfxGain);
    osc2.start(t);
    osc2.stop(t + 0.08);

    // Delicate crystalline harmonic
    const osc3 = this.ctx.createOscillator();
    const gain3 = this.ctx.createGain();
    osc3.type = 'sine';
    osc3.frequency.setValueAtTime(960, t);
    osc3.frequency.exponentialRampToValueAtTime(640, t + 0.16);

    gain3.gain.setValueAtTime(0.22, t);
    gain3.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc3.connect(gain3);
    gain3.connect(this.sfxGain);
    osc3.start(t);
    osc3.stop(t + 0.16);

    this.vibrate(22);
  }

  /**
   * Glass shattering line clear sound effect
   */
  public playLineClear(linesCount: number) {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;

    // 1. Procedural glass shatter noise burst
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.25);
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(2500, t);
    filter.frequency.exponentialRampToValueAtTime(6000, t + 0.25);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.7, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    whiteNoise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.sfxGain);
    whiteNoise.start(t);

    // 2. Crystalline resonant glass notes
    const baseFreqs = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98];
    const notesCount = Math.min(3 + linesCount, baseFreqs.length);

    for (let i = 0; i < notesCount; i++) {
      const osc = this.ctx.createOscillator();
      const noteGain = this.ctx.createGain();
      const delay = i * 0.04;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreqs[i] * (1 + (linesCount - 1) * 0.15), t + delay);

      noteGain.gain.setValueAtTime(0.38, t + delay);
      noteGain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.32);

      osc.connect(noteGain);
      noteGain.connect(this.sfxGain);

      osc.start(t + delay);
      osc.stop(t + delay + 0.32);
    }

    // Haptic pattern for line blast
    if (linesCount > 1) {
      this.vibrate([40, 30, 80, 40, 120]);
    } else {
      this.vibrate([35, 25, 50]);
    }
  }

  public playCombo(comboCount: number) {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const basePitch = 440 * Math.pow(1.12, Math.min(comboCount, 12));

    [0, 4, 7, 12].forEach((interval, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const freq = basePitch * Math.pow(2, interval / 12);
      const noteTime = t + idx * 0.05;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.35, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.25);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.25);
    });

    this.vibrate([50, 40, 80]);
  }

  public playMilestone() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98, 2093.0]; // C Major Fanfare

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const noteTime = t + idx * 0.07;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.45, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.4);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.4);
    });

    this.vibrate([80, 50, 100, 50, 150]);
  }

  public playHint() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(987.77, t); // B5
    osc.frequency.exponentialRampToValueAtTime(1318.5, t + 0.15); // E6

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.35);
  }

  public playRevive() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(880, t + 0.4);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.5);

    this.vibrate([100, 50, 200]);
  }

  public playGameOver() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const notes = [440, 392, 349.23, 293.66]; // Descending sad melody

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const noteTime = t + idx * 0.12;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.35, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.35);
    });

    this.vibrate([150, 100, 250]);
  }

  // --- Voice Reactions (Clear Woman's Voice in Excited Emotion & Prolonged Pronunciation) ---

  public speakReaction(
    phrase: 'Good!' | 'Wonderful!' | 'Excellent!' | 'Amazing!' | 'Unbelievable!' | 'Jackpot!' | 'You can do it!'
  ) {
    if (!this.voiceEnabled) return;

    const isJackpot = phrase === 'Jackpot!';

    // High-volume celebratory arcade chime / fanfare alongside voice
    this.playCelebrationCheer(isJackpot);

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();

        // Elongated, expressive phonetic spelling to make the voice enthusiastically pronounce each word longer
        const phoneticProlongedMap: Record<string, string> = {
          'Good!': 'Goooood!',
          'Wonderful!': 'Woooonderful!',
          'Excellent!': 'Exceeeellent!',
          'Amazing!': 'Amaaazing!',
          'Unbelievable!': 'Un-be-lieee-va-ble!',
          'Jackpot!': 'Jaaack-pot!',
          'You can do it!': 'You can do it!',
        };

        const spokenText = phoneticProlongedMap[phrase] || phrase;
        const utterance = new SpeechSynthesisUtterance(spokenText);

        // Maximum volume for crystal punchiness & clarity
        utterance.volume = 1.0;

        // Pronounce slightly longer with sustained, energetic tempo (0.82-0.85 rate draws out vowels)
        utterance.rate = 0.83;

        // Excited, cheerful feminine pitch
        const pitchMap: Record<string, number> = {
          'Good!': 1.30,
          'Wonderful!': 1.34,
          'Excellent!': 1.37,
          'Amazing!': 1.41,
          'Unbelievable!': 1.45,
          'Jackpot!': 1.48,
          'You can do it!': 1.32,
        };
        utterance.pitch = pitchMap[phrase] || 1.35;

        // Intelligent selection of the finest natural woman / female voice
        const voices = this.cachedVoices.length > 0 ? this.cachedVoices : window.speechSynthesis.getVoices();

        const femaleVoiceKeywords = [
          'natural',
          'jenny',
          'aria',
          'ava',
          'samantha',
          'victoria',
          'karen',
          'moira',
          'tessa',
          'fiona',
          'veena',
          'zira',
          'google us english female',
          'google us english',
          'google uk english female',
          'female',
          'woman',
          'sonia',
          'michelle',
          'hazel',
          'siri',
          'allison',
          'susan',
        ];

        const maleExclusions = ['david', 'mark', 'george', 'guy', 'male', 'richard', 'james', 'daniel', 'stefan', 'tom'];

        let selectedVoice: SpeechSynthesisVoice | undefined;

        // 1. Try finding by ranked priority list in English
        for (const name of femaleVoiceKeywords) {
          const match = voices.find(v => {
            const lower = v.name.toLowerCase();
            const notMale = !maleExclusions.some(m => lower.includes(m));
            return v.lang.startsWith('en') && notMale && lower.includes(name);
          });
          if (match) {
            selectedVoice = match;
            break;
          }
        }

        // 2. Fallback to any voice with female indicator
        if (!selectedVoice) {
          selectedVoice = voices.find(v => {
            const lower = v.name.toLowerCase();
            return v.lang.startsWith('en') && (lower.includes('female') || lower.includes('woman'));
          });
        }

        // 3. Fallback to non-male English voice
        if (!selectedVoice) {
          selectedVoice = voices.find(v => {
            const lower = v.name.toLowerCase();
            return v.lang.startsWith('en') && !maleExclusions.some(m => lower.includes(m));
          });
        }

        // 4. Default fallback to any English voice
        if (!selectedVoice) {
          selectedVoice = voices.find(v => v.lang.startsWith('en'));
        }

        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }

        // Short timeout bypasses Chromium bug where cancel() cancels subsequent synchronous speak()
        setTimeout(() => {
          try {
            window.speechSynthesis.speak(utterance);
          } catch {}
        }, 15);
      } catch {
        // Fallback tone already played
      }
    }
  }

  private playCelebrationCheer(isJackpot = false) {
    if (!this.soundEnabled || !this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // High volume crystal arpeggio burst
    const freqs = isJackpot
      ? [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98, 2093.0] // 7-note grand jackpot fanfare
      : [783.99, 1046.5, 1318.5, 1567.98, 2093.0]; // 5-note sparkle cheer

    freqs.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const noteTime = t + idx * 0.038;

      osc.type = isJackpot ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      const peakGain = (isJackpot ? 0.6 : 0.52) * (this.sfxVolume || 0.85);
      gain.gain.setValueAtTime(peakGain, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + (isJackpot ? 0.45 : 0.35));

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + (isJackpot ? 0.45 : 0.35));
    });
  }

  // --- Cool Neo-Cyber Synthwave & Chill Groove Background Music ---

  public startMusic() {
    if (!this.musicEnabled || this.isMusicPlaying) return;
    this.initCtx();
    if (!this.ctx || !this.musicGain) return;

    this.isMusicPlaying = true;
    this.currentStep = 0;

    // Cool 116 BPM Cyber Lo-Fi / Synthwave Groove (16th note step = 129.3ms)
    const stepDuration = 129;

    // Rich, stylish chord progression in Eb Minor / C# Dorian
    // 1. Ebm9: [Eb3, Bb3, Db4, F4]
    // 2. Bmaj7: [B2, F#3, Bb3, D#4]
    // 3. Db9:   [Db3, Ab3, C4, F4]
    // 4. Bbm7:  [Bb2, F3, Ab3, Db4]
    const chordProgressions = [
      [155.56, 233.08, 277.18, 349.23],
      [123.47, 185.00, 233.08, 311.13],
      [138.59, 207.65, 261.63, 349.23],
      [116.54, 174.61, 207.65, 277.18],
    ];

    // Deep rolling 808 synth bass notes synced to steps
    const bassSequence = [
      // Bar 1 (Ebm)
      77.78, null, 77.78, null, 155.56, null, 77.78, 116.54,
      null, 77.78, null, 155.56, 77.78, null, 103.83, null,
      // Bar 2 (Bmaj)
      61.74, null, 61.74, null, 123.47, null, 61.74, 92.50,
      null, 61.74, null, 123.47, 61.74, null, 92.50, null,
      // Bar 3 (Db)
      69.30, null, 69.30, null, 138.59, null, 69.30, 103.83,
      null, 69.30, null, 138.59, 69.30, null, 103.83, null,
      // Bar 4 (Bbm)
      58.27, null, 58.27, null, 116.54, null, 58.27, 87.31,
      null, 58.27, null, 116.54, 58.27, null, 87.31, 103.83,
    ];

    // Catchy, chill melodic arpeggio / lead notes (Eb Minor pentatonic scale)
    const melodyScale = [311.13, 369.99, 415.30, 466.16, 554.37, 622.25, 739.99];

    this.musicInterval = window.setInterval(() => {
      if (!this.ctx || !this.musicGain || !this.musicEnabled) return;

      const t = this.ctx.currentTime;
      const stepIn16 = this.currentStep % 16;
      const barIndex = Math.floor(this.currentStep / 16) % 4;
      const currentChord = chordProgressions[barIndex];

      // 1. Lush Analog Synth Chords (Soft Detuned Dual Pad with Filter Movement)
      if (stepIn16 === 0 || stepIn16 === 8) {
        currentChord.forEach((freq, idx) => {
          if (!this.ctx || !this.musicGain) return;

          // Warm dual oscillator (sawtooth + triangle)
          const osc1 = this.ctx.createOscillator();
          const osc2 = this.ctx.createOscillator();
          const padGain = this.ctx.createGain();
          const filter = this.ctx.createBiquadFilter();

          osc1.type = 'sawtooth';
          osc1.frequency.setValueAtTime(freq, t);

          osc2.type = 'triangle';
          osc2.frequency.setValueAtTime(freq * 1.003, t); // Subtle chorus detune

          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(650 + idx * 80, t);
          filter.frequency.exponentialRampToValueAtTime(1250, t + 0.4);
          filter.frequency.exponentialRampToValueAtTime(550, t + 0.95);
          filter.Q.setValueAtTime(1.8, t);

          padGain.gain.setValueAtTime(0.048, t);
          padGain.gain.exponentialRampToValueAtTime(0.001, t + 1.0);

          osc1.connect(filter);
          osc2.connect(filter);
          filter.connect(padGain);
          padGain.connect(this.musicGain);

          osc1.start(t);
          osc2.start(t);
          osc1.stop(t + 1.0);
          osc2.stop(t + 1.0);
        });
      }

      // 2. Deep Rolling 808 Synth Bass
      const bassFreq = bassSequence[this.currentStep % 64];
      if (bassFreq !== null && bassFreq !== undefined) {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        const bassFilter = this.ctx.createBiquadFilter();

        bassOsc.type = 'triangle';
        bassOsc.frequency.setValueAtTime(bassFreq, t);

        bassFilter.type = 'lowpass';
        bassFilter.frequency.setValueAtTime(320, t);

        bassGain.gain.setValueAtTime(0.18, t);
        bassGain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

        bassOsc.connect(bassFilter);
        bassFilter.connect(bassGain);
        bassGain.connect(this.musicGain);

        bassOsc.start(t);
        bassOsc.stop(t + 0.18);
      }

      // 3. Cool Crystalline Arpeggio & Lead Motif
      const shouldPlayMelody = stepIn16 % 2 === 1 || stepIn16 === 4 || stepIn16 === 12;
      if (shouldPlayMelody) {
        const noteIndex = (this.currentStep * 3 + barIndex * 2) % melodyScale.length;
        const noteFreq = melodyScale[noteIndex];

        const leadOsc = this.ctx.createOscillator();
        const leadGain = this.ctx.createGain();
        const leadFilter = this.ctx.createBiquadFilter();

        leadOsc.type = 'sine';
        leadOsc.frequency.setValueAtTime(noteFreq, t);

        leadFilter.type = 'bandpass';
        leadFilter.frequency.setValueAtTime(noteFreq * 1.5, t);
        leadFilter.Q.setValueAtTime(2.0, t);

        leadGain.gain.setValueAtTime(0.042, t);
        leadGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);

        leadOsc.connect(leadFilter);
        leadFilter.connect(leadGain);
        leadGain.connect(this.musicGain);

        leadOsc.start(t);
        leadOsc.stop(t + 0.16);
      }

      // 4. Subtle Chill Beat Pulse (Lo-Fi Warm Kick on 0, 8 & Crisp Hat on 4, 12)
      if (stepIn16 === 0 || stepIn16 === 8) {
        // Warm 808 Kick pulse
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.type = 'sine';
        kickOsc.frequency.setValueAtTime(110, t);
        kickOsc.frequency.exponentialRampToValueAtTime(42, t + 0.11);

        kickGain.gain.setValueAtTime(0.22, t);
        kickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

        kickOsc.connect(kickGain);
        kickGain.connect(this.musicGain);
        kickOsc.start(t);
        kickOsc.stop(t + 0.12);
      } else if (stepIn16 === 4 || stepIn16 === 12 || stepIn16 === 14) {
        // Soft analog shaker / closed hat tick
        const hatOsc = this.ctx.createOscillator();
        const hatGain = this.ctx.createGain();
        const hatFilter = this.ctx.createBiquadFilter();

        hatOsc.type = 'highpass' as unknown as OscillatorType;
        // High frequency triangle tick
        const hOsc = this.ctx.createOscillator();
        hOsc.type = 'triangle';
        hOsc.frequency.setValueAtTime(3800, t);
        hOsc.frequency.exponentialRampToValueAtTime(6200, t + 0.025);

        hatFilter.type = 'highpass';
        hatFilter.frequency.setValueAtTime(3200, t);

        hatGain.gain.setValueAtTime(0.028, t);
        hatGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.025);

        hOsc.connect(hatFilter);
        hatFilter.connect(hatGain);
        hatGain.connect(this.musicGain);

        hOsc.start(t);
        hOsc.stop(t + 0.025);
      }

      this.currentStep = (this.currentStep + 1) % 64;
    }, stepDuration);
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval !== null) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }

  // --- Haptics ---

  public vibrate(pattern: number | number[]) {
    if (!this.vibrationEnabled) return;
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Safe catch for browsers that restrict vibration without user gesture
      }
    }
  }
}

export const soundManager = new SoundManager();
