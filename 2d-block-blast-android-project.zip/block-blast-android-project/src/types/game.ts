export type Grid = (string | null)[][];

export interface ShapeDefinition {
  id: string;
  name: string;
  matrix: number[][]; // 1 for filled, 0 for empty
  weight: number; // spawn probability weight
}

export interface PlacedCell {
  row: number;
  col: number;
  color: string;
}

export interface Piece {
  id: string;
  shapeId: string;
  matrix: number[][];
  color: string;
  width: number;
  height: number;
}

export interface ThemeConfig {
  id: number;
  name: string;
  subtitle: string;
  blockColors: string[];
  boardGlowColor: string;
  gridLineColor: string;
  ambientLightColor: string;
  keyLightColor: string;
  bgGradient: string;
  accentColor: string;
  solidBoundaryColor: string;
}

export interface ShatterShard {
  id: string;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  rx: number;
  ry: number;
  rz: number;
  color: string;
  size: number;
  birth: number;
  lifetime: number;
}

export interface HintPlacement {
  pieceIndex: number;
  row: number;
  col: number;
  cells: [number, number][];
}

// 22 Diverse Tetrominoes, Pentominoes, Trominoes, and Blocks
export const SHAPE_DEFINITIONS: ShapeDefinition[] = [
  // 1x1 Single
  { id: 'dot', name: 'Single Cube', matrix: [[1]], weight: 2 },
  
  // 1x2 and 2x1
  { id: 'line-2-h', name: '2-Line H', matrix: [[1, 1]], weight: 3 },
  { id: 'line-2-v', name: '2-Line V', matrix: [[1], [1]], weight: 3 },

  // 1x3 and 3x1
  { id: 'line-3-h', name: '3-Line H', matrix: [[1, 1, 1]], weight: 3 },
  { id: 'line-3-v', name: '3-Line V', matrix: [[1], [1], [1]], weight: 3 },

  // 1x4 and 4x1
  { id: 'line-4-h', name: '4-Line H', matrix: [[1, 1, 1, 1]], weight: 2 },
  { id: 'line-4-v', name: '4-Line V', matrix: [[1], [1], [1], [1]], weight: 2 },

  // 1x5 and 5x1
  { id: 'line-5-h', name: '5-Line H', matrix: [[1, 1, 1, 1, 1]], weight: 1 },
  { id: 'line-5-v', name: '5-Line V', matrix: [[1], [1], [1], [1], [1]], weight: 1 },

  // 2x2 Square
  { id: 'square-2', name: '2x2 Box', matrix: [[1, 1], [1, 1]], weight: 4 },

  // 3x3 Big Square (rare rewarding piece)
  { id: 'square-3', name: '3x3 Giant Box', matrix: [[1, 1, 1], [1, 1, 1], [1, 1, 1]], weight: 1 },

  // Small Corner 2x2
  { id: 'corner-sm-tl', name: 'Small Corner TL', matrix: [[1, 1], [1, 0]], weight: 3 },
  { id: 'corner-sm-tr', name: 'Small Corner TR', matrix: [[1, 1], [0, 1]], weight: 3 },
  { id: 'corner-sm-bl', name: 'Small Corner BL', matrix: [[1, 0], [1, 1]], weight: 3 },
  { id: 'corner-sm-br', name: 'Small Corner BR', matrix: [[0, 1], [1, 1]], weight: 3 },

  // Large Corner 3x3
  { id: 'corner-lg-tl', name: 'Large Corner TL', matrix: [[1, 1, 1], [1, 0, 0], [1, 0, 0]], weight: 2 },
  { id: 'corner-lg-tr', name: 'Large Corner TR', matrix: [[1, 1, 1], [0, 0, 1], [0, 0, 1]], weight: 2 },
  { id: 'corner-lg-bl', name: 'Large Corner BL', matrix: [[1, 0, 0], [1, 0, 0], [1, 1, 1]], weight: 2 },
  { id: 'corner-lg-br', name: 'Large Corner BR', matrix: [[0, 0, 1], [0, 0, 1], [1, 1, 1]], weight: 2 },

  // T-Shapes
  { id: 't-up', name: 'T-Shape Up', matrix: [[1, 1, 1], [0, 1, 0]], weight: 2 },
  { id: 't-down', name: 'T-Shape Down', matrix: [[0, 1, 0], [1, 1, 1]], weight: 2 },
  { id: 't-left', name: 'T-Shape Left', matrix: [[1, 0], [1, 1], [1, 0]], weight: 2 },
  { id: 't-right', name: 'T-Shape Right', matrix: [[0, 1], [1, 1], [0, 1]], weight: 2 },

  // L-Shapes (3x2)
  { id: 'l-normal', name: 'L-Shape', matrix: [[1, 0], [1, 0], [1, 1]], weight: 2 },
  { id: 'j-normal', name: 'J-Shape', matrix: [[0, 1], [0, 1], [1, 1]], weight: 2 },

  // S & Z Shapes
  { id: 's-shape', name: 'S-Shape', matrix: [[0, 1, 1], [1, 1, 0]], weight: 2 },
  { id: 'z-shape', name: 'Z-Shape', matrix: [[1, 1, 0], [0, 1, 1]], weight: 2 },

  // Plus shape
  { id: 'plus', name: 'Plus Shape', matrix: [[0, 1, 0], [1, 1, 1], [0, 1, 0]], weight: 1 },
];

export const THEMES: ThemeConfig[] = [
  {
    id: 0,
    name: 'Cyber Neon',
    subtitle: 'Standard Core Grid',
    blockColors: ['#00F0FF', '#FF0055', '#7928CA', '#00FF66', '#FFB800'],
    boardGlowColor: '#00e5ff',
    gridLineColor: '#1e293b',
    ambientLightColor: '#0f172a',
    keyLightColor: '#38bdf8',
    bgGradient: 'from-slate-950 via-cyan-950 to-slate-900',
    accentColor: '#00f0ff',
    solidBoundaryColor: '#00F0FF',
  },
  {
    id: 1,
    name: 'Synthwave Sunset',
    subtitle: '5,000 Milestone Unlocked',
    blockColors: ['#FF2A85', '#FF7A00', '#FFD600', '#9D00FF', '#00F0FF'],
    boardGlowColor: '#ff007f',
    gridLineColor: '#371e3d',
    ambientLightColor: '#200827',
    keyLightColor: '#ff77aa',
    bgGradient: 'from-fuchsia-950 via-purple-950 to-slate-950',
    accentColor: '#ff2a85',
    solidBoundaryColor: '#FF007F',
  },
  {
    id: 2,
    name: 'Cosmic Aurora',
    subtitle: '10,000 Milestone Unlocked',
    blockColors: ['#00FFB2', '#00A3FF', '#7000FF', '#39FF14', '#FF00A0'],
    boardGlowColor: '#00ffb2',
    gridLineColor: '#0d2825',
    ambientLightColor: '#061a19',
    keyLightColor: '#22d3ee',
    bgGradient: 'from-emerald-950 via-teal-950 to-slate-950',
    accentColor: '#00ffb2',
    solidBoundaryColor: '#00FF66',
  },
  {
    id: 3,
    name: 'Solar Flare',
    subtitle: '15,000 Milestone Unlocked',
    blockColors: ['#FFB703', '#FB8500', '#D00000', '#FF0054', '#FFEE88'],
    boardGlowColor: '#ffaa00',
    gridLineColor: '#3d250d',
    ambientLightColor: '#2b1404',
    keyLightColor: '#fbbf24',
    bgGradient: 'from-amber-950 via-orange-950 to-slate-950',
    accentColor: '#ffb703',
    solidBoundaryColor: '#FF9900',
  },
  {
    id: 4,
    name: 'Obsidian Prism',
    subtitle: '20,000 Milestone Unlocked',
    blockColors: ['#E0AAFF', '#C77DFF', '#9D4EDD', '#7B2CBF', '#5A189A'],
    boardGlowColor: '#c77dff',
    gridLineColor: '#241438',
    ambientLightColor: '#170b24',
    keyLightColor: '#d8b4fe',
    bgGradient: 'from-violet-950 via-indigo-950 to-slate-950',
    accentColor: '#c77dff',
    solidBoundaryColor: '#B026FF',
  },
  {
    id: 5,
    name: 'Hyper Diamond',
    subtitle: '25,000+ Ultimate Master',
    blockColors: ['#FFFFFF', '#38BDF8', '#818CF8', '#F472B6', '#34D399'],
    boardGlowColor: '#ffffff',
    gridLineColor: '#334155',
    ambientLightColor: '#0f172a',
    keyLightColor: '#ffffff',
    bgGradient: 'from-sky-950 via-blue-950 to-slate-950',
    accentColor: '#38bdf8',
    solidBoundaryColor: '#FFD700',
  },
];

export function getThemeForScore(score: number): ThemeConfig {
  const milestoneIndex = Math.floor(score / 5000);
  if (milestoneIndex < THEMES.length) {
    return THEMES[milestoneIndex];
  }
  // Procedural infinite themes for high scores!
  const cycle = milestoneIndex % THEMES.length;
  const baseTheme = THEMES[cycle];
  const hueShift = (milestoneIndex * 47) % 360;
  return {
    ...baseTheme,
    id: milestoneIndex,
    name: `Prism Phase ${milestoneIndex + 1}`,
    subtitle: `${(milestoneIndex * 5000).toLocaleString()} Milestone Tier`,
    accentColor: `hsl(${hueShift}, 100%, 65%)`,
    boardGlowColor: `hsl(${hueShift}, 100%, 60%)`,
    solidBoundaryColor: `hsl(${hueShift}, 100%, 55%)`,
  };
}
